# data_operations.py

import pickle
import os
import re
import time
import pandas as pd
import numpy as np
import sqlite3
from pathlib import Path
import traceback
import bisect
import sys
import math
import gc
import json
import dask.dataframe as dd
import uuid
import openpyxl
from distributed import Future
import random
import matplotlib.pyplot as plt

from dask.distributed import Client, LocalCluster, wait, as_completed
from dask.delayed import delayed
from dask.base import compute
from operator import itemgetter
from datetime import datetime, timedelta
from config import setup_logging, BLOCKS_SQL_DATA, TRAINED_MODELS_DIR, TOTAL_AMOUNT_MORE_THAN_BTC, MIN_TXS_PER_WALLET, BLOCK_HEIGHT_BLOCK_TIME_MAP_DIR_FILE, APP_TEMP_DIR
from modules.dask_client_init.get_dask_client import get_dask_client, close_dask_client
from modules.tests.tests_utils_funcs import save_parquet, load_parquet
from . import service_funcs as sf
from . import data_operations as do

logger = setup_logging(__name__)
script_dir = os.path.dirname(os.path.abspath(__file__))
module_name_for_temp_dir = __name__.replace('.', '_')
dir_for_temp_files_of_module = os.path.join(APP_TEMP_DIR, module_name_for_temp_dir)
os.makedirs(dir_for_temp_files_of_module, exist_ok=True)
os.chdir(script_dir)

def get_corelation_by_tmsp_df(TEST, filter_params, correlation_type, tmps, chunk_size = 300)  : # -> peaks_data_in_iteration_to_teach, peaks_data_in_iteration_to_profit_test
    logger.info("Start get_corelation_df")
    print('попробовать разбивать на чанки не по кошелькам а по макс кол-ву строк из бд')
    print('есть возможность таскать данные в даск от sql')
    teaching_start_tmsp = tmps['teaching_start_tmsp']
    teaching_end_tmsp = tmps['teaching_end_tmsp']
    interval_with_peaks_df = get_peaks_of_iteration(teaching_start_tmsp, teaching_end_tmsp)
    wallets_of_peaks_list = get_wallets_of_peaks_list(interval_with_peaks_df, filter_params)
    
    if TEST:
        wallets_of_peaks_list = random.sample(wallets_of_peaks_list, int(len(wallets_of_peaks_list)*TEST))
    chunks_list = get_chunks_of_wallets(wallets_of_peaks_list, chunk_size)

    dask_client = get_dask_client()
    all_wallets_corelation_ddf, all_txs_of_wallets_ddf = get_corelation_of_wallets_df_with_dask(dask_client, chunks_list, tmps, correlation_type, chunk_size, filter_params)
    all_wallets_corelation_ddf = all_wallets_corelation_ddf.persist()
    wait(all_wallets_corelation_ddf)
    wait(all_txs_of_wallets_ddf)

    logger.info("\033[0mStart get_data_for_teach_with_dask in get_corelation_df\033[0m")
    cor_data_in_iteration_to_teach_df, cor_data_in_iteration_to_profit_test_df = get_data_for_teach_with_dask(tmps, all_txs_of_wallets_ddf, all_wallets_corelation_ddf, correlation_type)

    # print('len(cor_data_in_iteration_to_teach_df)')
    # print(len(cor_data_in_iteration_to_teach_df))
    logger.info("Closing dask client")
    close_dask_client(dask_client)

    cor_data_in_iteration_to_teach_df.reset_index(inplace=True)
    cor_data_in_iteration_to_profit_test_df.reset_index(inplace=True)

    return cor_data_in_iteration_to_teach_df, cor_data_in_iteration_to_profit_test_df

def get_half_of_teaching_period(tmsps):
    how_many_sec_in_month = sf.get_secs_in_month()
    half_of_teaching_period = (tmsps['teaching_end_tmsp']-tmsps['teaching_start_tmsp'])//2
    if half_of_teaching_period < how_many_sec_in_month*3:
        half_of_teaching_period = None
    return half_of_teaching_period

def get_blocks_by_tmsp(timestamps, direction='<'):
    """
    timestamps: список (list) временных меток, для которых нужно найти ближайшие блоки
    direction:  '<' или '>' (означает, хотим блок по timestamp'у чуть меньше (backward)
                или чуть больше (forward))

    Возвращает список block_heights той же длины, что и timestamps.
    Если для какой-то метки не нашлось подходящего блока (например, слишком маленькая/большая),
    в результате будет NaN.
    """
    # Создадим вспомогательный df с колонками:
    #   "ts"       - сама временная метка
    #   "orig_idx" - индекс для восстановления исходного порядка
    query_df = pd.DataFrame({'ts': timestamps, 'orig_idx': range(len(timestamps))})
    # Обязательно сортируем по 'ts', т.к. merge_asof требует отсортированные данные
    query_df = query_df.sort_values('ts')
    blocks_df = pd.read_parquet(BLOCK_HEIGHT_BLOCK_TIME_MAP_DIR_FILE)
    # print(blocks_df.info())
    # Убедимся, что blocks_df отсортирован по block_times:
    blocks_df_sorted = blocks_df.sort_values('block_times')

    # Настраиваем направление
    if direction == 'backward':
        # Ищем блок, у которого block_times <= ts
        # (т.е. "backward" по времени)
        merged = pd.merge_asof(
            query_df, 
            blocks_df_sorted,
            left_on='ts',
            right_on='block_times',
            direction='backward'
        )
    else:
        # direction == 'forward'
        # Ищем блок, у которого block_times >= ts
        # (т.е. "forward" по времени)
        merged = pd.merge_asof(
            query_df, 
            blocks_df_sorted,
            left_on='ts',
            right_on='block_times',
            direction='forward'
        )

    # Возвращаемся к исходному порядку timestamps
    merged = merged.sort_values('orig_idx')
    # В merged теперь есть колонки: ts, orig_idx, block_times, block_heights
    # Если не нашлось подходящего блока, block_heights = NaN
    result_list = merged['block_heights'].tolist()
    if len(result_list) == 1:
        result_list = result_list[0]
    return result_list

def get_corelation_of_wallets_df_with_dask(dask_client, chunks_list, tmps, correlation_type, chunk_size, filter_params, correlation_threshold = 0.3):
    logger.info("\033[34mStart get_corelation_of_wallets_df_with_dask\033[0m")
    # НАДО ПОПРОБОВАТЬ НЕ ЧЕРЕЗ DELAY А ЧЕРЕЗ MAP ИЛИ GATHER
    peaks_data = sf.get_peaks_df()
    peaks_data_scattered = dask_client.scatter(peaks_data, broadcast=True)
    print('ОТФИЛЬТРОВАТЬ TXS ОТ КОШЕЛЬКОВ БЕЗ КОРРЕЛЯЦИИ')
    print('а почему корреляции нет? должна же быть хотя бы минимальная')

    # print('peaks_data.head()')
    # print(peaks_data.loc[peaks_data['Sell']!=0].head())
    # print(peaks_data.loc[peaks_data['Buy']!=0].head())    

    txs_dir = os.path.join(dir_for_temp_files_of_module, 'txs_of_chunk_with_intervals')
    os.makedirs(txs_dir, exist_ok=True)
    cor_dir = os.path.join(dir_for_temp_files_of_module, 'correlation_wallets_df')
    os.makedirs(cor_dir, exist_ok=True)
    correlation_threshold = filter_params['correlation_threshold']
    @delayed
    def process_chunk(chunk_wallets, peaks_data, tmps, correlation_type, chunk_size, correlation_threshold):
        cmlt_start_tmsp = tmps['cmlt_start_tmsp']
        profit_test_end_tmsp = tmps['profit_test_end_tmsp']
        teaching_start_tmsp = tmps['teaching_start_tmsp']
        teaching_end_tmsp = tmps['teaching_end_tmsp']
        half_of_teaching_period = get_half_of_teaching_period(tmps)

        cmlt_start_block = get_blocks_by_tmsp([cmlt_start_tmsp], direction='forward')
        profit_test_end_block = get_blocks_by_tmsp([profit_test_end_tmsp], direction='backward')      

        txs_of_chunk = get_txs_of_wallets_list_between_blocks(chunk_wallets, cmlt_start_block, profit_test_end_block, chunk_size)
        #ind     Transaction_id      Wallet_id      Btc_block_time_price  Block_time     Block_height      Block_hash           n  Amount       Transactions_Count
        #15738  9d409af31b848113b  3B4ysFKQdtNsAb          26535.580       1695814019        809569  00000000000008693470a0616  0   0.006                   1
        if txs_of_chunk.empty:
            return False
        
        txs_of_chunk = normalize_amount(txs_of_chunk)
        txs_of_chunk_for_correlation = txs_of_chunk.loc[(txs_of_chunk['Block_time'] >= teaching_start_tmsp) & 
                                                        (txs_of_chunk['Block_time'] <= teaching_end_tmsp)]

        txs_of_chunk_for_correlation = filter_txs_of_chunk(txs_of_chunk_for_correlation, half_of_teaching_period, teaching_end_tmsp)
        txs_of_chunk_for_correlation = txs_of_chunk_for_correlation.loc[txs_of_chunk_for_correlation['Wallet_id']!='nan']
        if txs_of_chunk_for_correlation.empty:
            return False 

        txs_of_chunk_for_correlation = import_peak_intervals(txs_of_chunk_for_correlation, peaks_data)
        if txs_of_chunk_for_correlation.empty:
            return False 
        txs_of_chunk_for_correlation = txs_of_chunk_for_correlation.fillna(0)

        correlation_wallets_df = calculate_correlations_of_wallets(txs_of_chunk_for_correlation, correlation_type, correlation_threshold)
        if correlation_wallets_df.empty:
            return False 
        correlation_wallets_df = correlation_wallets_df.fillna(0)
        correlation_wallets_df['Wallet_id'] = correlation_wallets_df['Wallet_id'].astype(str)
        txs_of_chunk = txs_of_chunk.loc[txs_of_chunk['Wallet_id'].isin(correlation_wallets_df['Wallet_id'])]

        uuid_str = str(uuid.uuid4())[:8]
        temp_files_txs_path = os.path.join(txs_dir, f'txs_of_chunk_{uuid_str}.parquet')
        temp_files_wallets_cor_path = os.path.join(cor_dir, f'wallets_cor_{uuid_str}.parquet')
        correlation_wallets_df.to_parquet(temp_files_wallets_cor_path, index=False)
        txs_of_chunk.to_parquet(temp_files_txs_path, index=False)

        del txs_of_chunk, txs_of_chunk_for_correlation, correlation_wallets_df
        gc.collect()
        return True

    delayed_tasks = []
    for chunk_wallets in chunks_list:
        task = delayed(process_chunk)(chunk_wallets, peaks_data_scattered, tmps, correlation_type, chunk_size, correlation_threshold)
        delayed_tasks.append(task)

    results = compute(*delayed_tasks)

    all_txs_of_wallets_ddf = dd.read_parquet(txs_dir, engine='pyarrow')
    all_wallets_corelation_ddf = dd.read_parquet(cor_dir, engine='pyarrow')
    if len(all_txs_of_wallets_ddf) == 0:
        logger.info("ALARM! No data in all_txs_of_wallets_ddf")
    return all_wallets_corelation_ddf, all_txs_of_wallets_ddf

def calculate_correlations_of_wallets(txs_of_chunk_with_intervals, correlation_threshold = None, correlation_type = None):
    correlation_wallets_df = pd.DataFrame()
    if correlation_type:
        if correlation_type == 'basic':
            correlation_wallets_df = calculate_correlation_basic(txs_of_chunk_with_intervals, correlation_threshold)
        elif correlation_type == 'optimized':
            correlation_wallets_df = calculate_correlations_of_wallets_optimized(txs_of_chunk_with_intervals)
    else:
        logger.error('Correlation_type is None!')
        return None

    return correlation_wallets_df

def calculate_pearson_correlation_of_group(group, correlation_threshold = None, **kwargs):
    correlation_matrix = group[
        ['Normalized_sell_amount', 'Normalized_buy_amount', 'in_sell_interval', 'in_buy_interval']
            ].corr(method='pearson')
    
    if correlation_threshold:
        conditions = [
            abs(correlation_matrix.loc['Normalized_sell_amount', 'in_sell_interval']) >= correlation_threshold,
            abs(correlation_matrix.loc['Normalized_buy_amount', 'in_buy_interval']) >= correlation_threshold,
            ]

    if not all(conditions):
        return pd.Series({  # #comment: Возвращаем Series с предопределёнными ключами
            'Wallet_id': None,
            'Normalized_sell_amount_in_sell_interval': np.nan,
            'Normalized_sell_amount_in_buy_interval': np.nan,
            'Normalized_buy_amount_in_buy_interval': np.nan,
            'Normalized_buy_amount_in_sell_interval': np.nan,
            'sell_txs_qnty': 0,
            'buy_txs_qnty': 0
        })  # #comment: Если хотя бы одна пара не удовлетворяет порогу, группа исключается

    wallet_id = group['Wallet_id'].iloc[0]
    # num_transactions = len(group)
    sell_txs = len(group.loc[group['Amount'] < 0]) 
    buy_txs = len(group.loc[group['Amount'] > 0])
    result = pd.Series([
        wallet_id,
        correlation_matrix.loc['Normalized_sell_amount', 'in_sell_interval'],
        correlation_matrix.loc['Normalized_sell_amount', 'in_buy_interval'],
        correlation_matrix.loc['Normalized_buy_amount', 'in_buy_interval'],
        correlation_matrix.loc['Normalized_buy_amount', 'in_sell_interval'],
        sell_txs,
        buy_txs
        ], index=[
            'Wallet_id',
            'Normalized_sell_amount_in_sell_interval',
            'Normalized_sell_amount_in_buy_interval',
            'Normalized_buy_amount_in_buy_interval',
            'Normalized_buy_amount_in_sell_interval',
            'sell_txs_qnty',
            'buy_txs_qnty'
        ])
    return result

def calculate_correlation_basic(txs_df, correlation_threshold=0.3):
    # переделать в даск дф?
    grouped = txs_df.groupby('Wallet_id')
    meta = {
        'Wallet_id': str,
        'Normalized_sell_amount_in_sell_interval': float,
        'Normalized_sell_amount_in_buy_interval': float,
        'Normalized_buy_amount_in_buy_interval': float,
        'Normalized_buy_amount_in_sell_interval': float,
        'sell_txs_qnty': int,
        'buy_txs_qnty': int
        }

    correlation_data = grouped.apply(calculate_pearson_correlation_of_group, meta=meta, correlation_threshold=correlation_threshold)
    
    correlation_df = pd.DataFrame(correlation_data)
    correlation_df = correlation_df.reset_index(drop=True)
    correlation_df['Wallet_id'] = correlation_df['Wallet_id'].astype(str)
    correlation_df = correlation_df.fillna(0.0)
    # print(correlation_df)
    if correlation_df.empty:
        return pd.Series({  
            'Wallet_id': None,  # #comment: Заполняем идентификатор по умолчанию
            'Normalized_sell_amount_in_sell_interval': np.nan,  # #comment: Возвращаем NaN для корреляций
            'Normalized_sell_amount_in_buy_interval': np.nan,
            'Normalized_buy_amount_in_buy_interval': np.nan,
            'Normalized_buy_amount_in_sell_interval': np.nan,
            'sell_txs_qnty': 0,  # #comment: Возвращаем 0 для количества транзакций
            'buy_txs_qnty': 0
            })
    
    correlation_df['Weighted_sell_correlation'] = correlation_df['Normalized_sell_amount_in_sell_interval'] * correlation_df['sell_txs_qnty']
    correlation_df['Weighted_buy_correlation'] = correlation_df['Normalized_buy_amount_in_buy_interval'] * correlation_df['buy_txs_qnty']
    correlation_df['Weighted_sell_anti_correlation'] = correlation_df['Normalized_sell_amount_in_buy_interval'] * correlation_df['sell_txs_qnty']
    correlation_df['Weighted_buy_anti_correlation'] = correlation_df['Normalized_buy_amount_in_sell_interval'] * correlation_df['buy_txs_qnty']
    correlation_df['SASI-SABI'] = correlation_df['Normalized_sell_amount_in_sell_interval']-correlation_df['Normalized_sell_amount_in_buy_interval']
    correlation_df['BABI-BASI'] = correlation_df['Normalized_buy_amount_in_buy_interval']-correlation_df['Normalized_buy_amount_in_sell_interval']
    correlation_df['WSASI-WSABI'] = correlation_df['Weighted_sell_correlation']-correlation_df['Weighted_sell_anti_correlation']
    correlation_df['WBABI-WBASI'] = correlation_df['Weighted_buy_correlation']-correlation_df['Weighted_buy_anti_correlation']
    return correlation_df

def calculate_correlations_of_wallets_optimized(txs_of_chunk_with_intervals):
    # logger.info('Start calculate_correlations_of_wallets_optimized')
    """
    Вычисляет корреляционные коэффициенты для каждого кошелька.
    """

    txs_of_chunk_with_intervals = txs_of_chunk_with_intervals.assign(
        NSA_ISI = txs_of_chunk_with_intervals.get('Normalized_sell_amount', 0) * txs_of_chunk_with_intervals.get('in_sell_interval', 0),
        NSA_IBI = txs_of_chunk_with_intervals.get('Normalized_sell_amount', 0) * txs_of_chunk_with_intervals.get('in_buy_interval', 0),
        NBA_IBI = txs_of_chunk_with_intervals.get('Normalized_buy_amount', 0)  * txs_of_chunk_with_intervals.get('in_buy_interval', 0),
        NBA_ISI = txs_of_chunk_with_intervals.get('Normalized_buy_amount', 0)  * txs_of_chunk_with_intervals.get('in_sell_interval', 0)
        )

    grouped = txs_of_chunk_with_intervals.groupby('Wallet_id').agg({
        'Normalized_sell_amount': ['mean', 'std'],
        'Normalized_buy_amount': ['mean', 'std'],
        'in_sell_interval': ['mean', 'std'],
        'in_buy_interval': ['mean', 'std'],
        'Amount': [lambda x: x[x < 0].sum(),  # сумма продаж
                lambda x: x[x > 0].sum()], # сумма покупок
        'NSA_ISI': ['mean', 'std', 'sum'],
        'NSA_IBI': ['mean', 'std', 'sum'],
        'NBA_IBI': ['mean', 'std', 'sum'],
        'NBA_ISI': ['mean', 'std', 'sum']
    })
    # Переименовываем столбцы для удобства
    grouped.columns = ['_'.join(col).strip() for col in grouped.columns.values]

    # Вычисляем корреляционные коэффициенты
    grouped = grouped.assign(
        # Старые "корреляции" на основе mean + std
        cor_NSA_ISI_mean = (
            (grouped['NSA_ISI_mean'] - grouped['Normalized_sell_amount_mean'] * grouped['in_sell_interval_mean']) /
            (grouped['Normalized_sell_amount_std'] * grouped['in_sell_interval_std'])
        ),
        cor_NSA_IBI_mean = (
            (grouped['NSA_IBI_mean'] - grouped['Normalized_sell_amount_mean'] * grouped['in_buy_interval_mean']) /
            (grouped['Normalized_sell_amount_std'] * grouped['in_buy_interval_std'])
        ),
        cor_NBA_IBI_mean = (
            (grouped['NBA_IBI_mean'] - grouped['Normalized_buy_amount_mean'] * grouped['in_buy_interval_mean']) /
            (grouped['Normalized_buy_amount_std'] * grouped['in_buy_interval_std'])
        ),
        cor_NBA_ISI_mean = (
            (grouped['NBA_ISI_mean'] - grouped['Normalized_buy_amount_mean'] * grouped['in_sell_interval_mean']) /
            (grouped['Normalized_buy_amount_std'] * grouped['in_sell_interval_std'])
        ))
    
    grouped = grouped.fillna(0.0)

    # Добавляем дополнительные взвешенные корреляции
    grouped = grouped.assign(
        Weighted_sell_correlation_mean = grouped['cor_NSA_ISI_mean'] * grouped['Amount_<lambda_0>'],
        Weighted_buy_correlation_mean = grouped['cor_NBA_IBI_mean'] * grouped['Amount_<lambda_1>'],
        Weighted_sell_anti_correlation_mean = grouped['cor_NSA_IBI_mean'] * grouped['Amount_<lambda_0>'],
        Weighted_buy_anti_correlation_mean = grouped['cor_NBA_ISI_mean'] * grouped['Amount_<lambda_1>'],
        SASI_SABI_mean = grouped['cor_NSA_ISI_mean'] - grouped['cor_NSA_IBI_mean'],
        BABI_BASI_mean = grouped['cor_NBA_IBI_mean'] - grouped['cor_NBA_ISI_mean']
    )
    grouped = grouped.assign(
        WSASI_WSABI_mean = grouped['Weighted_sell_correlation_mean'] - grouped['Weighted_sell_anti_correlation_mean'],
        WBABI_WBASI_mean = grouped['Weighted_buy_correlation_mean'] - grouped['Weighted_buy_anti_correlation_mean']
    )


    # Создаём итоговый DataFrame
    correlation_df = grouped.reset_index()
    # print(correlation_df.head())

    del grouped, txs_of_chunk_with_intervals
    gc.collect()

    return correlation_df

def calculate_in_10_min_period(df):
    df['in_10_min_period'] = (
        (df['Block_time'] >= (df['Nearest_tmps_from_learning_data'] - 300)) &
        (df['Block_time'] <= (df['Nearest_tmps_from_learning_data'] + 300))
    )
    return df

def get_data_for_teach_with_dask(tmps, all_txs_of_wallets_ddf, correlation_wallets_ddf, correlation_type=None, converge_test=None, dir_for_save_test_data=None):
    logger.info("Start get_data_for_teach_with_dask")
    # print('print(correlation_wallets_ddf.head(1))')
    # print(correlation_wallets_ddf.head(1))

    cmlt_start_tmsp = tmps['cmlt_start_tmsp']
    profit_test_end_tmsp = tmps['profit_test_end_tmsp']

    # Получаем интервалы
    interval_with_peaks_df = get_peaks_of_iteration(cmlt_start_tmsp, profit_test_end_tmsp)
    # print('interval_with_peaks_df head 3')
    # print(interval_with_peaks_df.head(3))

    interval_with_peaks_df = interval_with_peaks_df.drop(columns=['Trade', 'Start_interval', 'End_interval'])
    interval_with_peaks_ddf = dd.from_pandas(interval_with_peaks_df, npartitions=1)

    all_txs_of_wallets_ddf = ensure_dask_dataframe(all_txs_of_wallets_ddf)
    correlation_wallets_ddf = ensure_dask_dataframe(correlation_wallets_ddf)

    # Объединяем транзакции с корреляциями по Wallet_id
    txs_ddf = all_txs_of_wallets_ddf.merge(correlation_wallets_ddf, on='Wallet_id', how='left')
    txs_ddf = txs_ddf.sort_values('Block_time').persist()

    if correlation_type == 'basic' or correlation_type == None:
        data_for_teach_df, data_for_profit_test_df = teach_n_test_data_with_basic_corrs(txs_ddf, interval_with_peaks_ddf, tmps, converge_test, dir_for_save_test_data)
    elif correlation_type == 'optimized':
        data_for_teach_df, data_for_profit_test_df = teach_n_test_data_with_optimized_corrs(txs_ddf, interval_with_peaks_ddf, tmps)
    return data_for_teach_df, data_for_profit_test_df

def teach_n_test_data_with_basic_corrs(txs_ddf, interval_with_peaks_ddf, tmps, converge_test=None, dir_for_save_test_data=None):
    if dir_for_save_test_data and converge_test:
        dir_for_temp_files_of_module = dir_for_save_test_data
    # возможно, проблема с несходимостью модели тут
    # что мне тут нуно сделать
    # у меня есть интервалы с tmps и моментами продаж и покупок
    # и список транзакций с кошельками и их корреляциями - надо учитывать взвешенные селлинг и баинг? или уже учтено?
    # я соединяю дфы и группирую их на промежутки по -300 и +300 от tmps с покупками и продажами  
    # ??? 

    # ПРАВИЛЬНЫЙ СПОСОБ
    # МЫ БЕРЕМ СТРОКИ С МЕТКАМИ И interval_with_peaks_ddf, СТРОКИ БЕРЕМ ОТДЛЕЛЬНО, МБ ПОСТРОЧНАЯ ОБРАБОТКА
    # СОБИРАЕМ ВСЕ TXS ИЗ ВРЕМЕННОГО ПРОМЕЖУТКА, + И - 300 СЕК,  С КОРРЕЛЯЦИЯМИ - ДЕЛАЕМ ГРУПИРОВКУ С СУММИРОВАНИЕМ КОРРЕЛЯЦИЙ
    # И ПОТОМ УЖЕ СЧИТАЕМ КУММУЛЯТИВНЫЕ  
    print('test?')
    print(converge_test)
    
    teaching_start_tmsp = tmps['teaching_start_tmsp']
    teaching_end_tmsp = tmps['teaching_end_tmsp']
    profit_test_start_tmsp = tmps['profit_test_start_tmsp']
    profit_test_end_tmsp = tmps['profit_test_end_tmsp']

    if converge_test:
        interval_with_peaks_ddf.to_parquet(os.path.join(dir_for_temp_files_of_module, '1_interval_with_peaks_ddfs'))
        txs_ddf.to_parquet(os.path.join(dir_for_temp_files_of_module, '2_txs_ddfs'))

    merged_txs_n_intervals_ddf = dd.merge_asof(
        txs_ddf,
        interval_with_peaks_ddf[['Timestamp']],
        left_on='Block_time',
        right_on='Timestamp',
        direction='nearest'
    )

    if converge_test:
        merged_txs_n_intervals_ddf.to_parquet(os.path.join(dir_for_temp_files_of_module, '3_merged_txs_n_intervals_ddf'))
    # print(merged_ddf.head(10))
    # РАЗОБРАТЬСЯ С ЭТОЙ ХУЙНЕЙ НИЖЕ!!!!!! С ПРОВЕРКОЙ НА ПОПАДАНИЕ В ИНТЕРВАЛЫ calculate_in_10_min_period

    merged_txs_n_intervals_ddf['Nearest_tmps_from_learning_data'] = merged_txs_n_intervals_ddf['Timestamp']
    # print(merged_ddf.head(10))

    # merged_ddf = calculate_in_10_min_period(merged_ddf).persist()

    # Убираем ненужные столбцы (например, Amount)
    merged_txs_n_intervals_ddf = merged_txs_n_intervals_ddf.drop(columns=['Transaction_id', 'Wallet_id', 'Timestamp', 'Block_hash', 'Amount'], errors='ignore')  # Изменено: удалён столбец Amount
    
    grouped_txs_n_intervals_on_tmsp = merged_txs_n_intervals_ddf.groupby('Nearest_tmps_from_learning_data').agg({
        'Weighted_sell_correlation': 'sum',
        'Weighted_buy_correlation': 'sum',
        'Weighted_sell_anti_correlation': 'sum',
        'Weighted_buy_anti_correlation': 'sum',
        'WSASI-WSABI': 'sum',
        'WBABI-WBASI': 'sum',
        'Normalized_sell_amount_in_sell_interval': 'sum',
        'Normalized_sell_amount_in_buy_interval': 'sum',
        'Normalized_buy_amount_in_buy_interval': 'sum',
        'Normalized_buy_amount_in_sell_interval': 'sum',
        'SASI-SABI': 'sum',
        'BABI-BASI': 'sum'
        })
    
    if converge_test:
        grouped_txs_n_intervals_on_tmsp.to_parquet(os.path.join(dir_for_temp_files_of_module, '4_grouped_txs_n_intervals_on_tmsp'))
    
    data_for_teach_ddf = interval_with_peaks_ddf.merge(
        grouped_txs_n_intervals_on_tmsp,
        left_on='Timestamp',
        right_on='Nearest_tmps_from_learning_data',
        how='left'
        )
    

    data_for_teach_ddf = data_for_teach_ddf.fillna(0)
    data_for_teach_ddf['Action'] = data_for_teach_ddf['Buy'] - data_for_teach_ddf['Sell']
    data_for_teach_df = data_for_teach_ddf.compute()

    if converge_test:
        data_for_teach_ddf.to_parquet(os.path.join(dir_for_temp_files_of_module, '5_data_for_teach_ddf.parquet'))

    data_for_teach_df['CMLTV_WSC'] = 0
    data_for_teach_df['CMLTV_WBC'] = 0
    data_for_teach_df['CMLTV_WSAC'] = 0
    data_for_teach_df['CMLTV_WBAC'] = 0

    data_for_teach_df['CMLTV_N_Sell_amount_in_sell_interval'] = 0
    data_for_teach_df['CMLTV_N_Buy_amount_in_buy_interval'] = 0
    data_for_teach_df['CMLTV_SASI-SABI'] = 0
    data_for_teach_df['CMLTV_BABI-BASI'] = 0
    data_for_teach_df['CMLTV_WSASI-WSABI'] = 0
    data_for_teach_df['CMLTV_WBABI-WBASI'] = 0


    # ДОБАВИТЬ В ПАРАМЕТРЫ МОДЕЛИ ДЛЯ ТЕСТА В ПАРАМ ГРИД. ПЕРЕДЕЛАТЬ ФУНКЦИЮ ТЕСТИРОВАНИЯ ПАРАМ ГРИДА ПОД РАЗНЫЕ
        # data_for_teach_df
        # посмтроить иерархию - сначала разные параметры 
        # data_for_teach_df -> model_param ->.........додумать
 
    # период затухания куммулятивных сумм
    # ранее использовал 3
    time_frame_hours = 6
    tau = time_frame_hours*6  # количество строк за 3 часа (3 часа = 18 строк по 10 минут)
    alpha = 1 - math.exp(-1 / tau) # коэффициент затухания

    data_for_teach_df['CMLTV_WSC'] = data_for_teach_df['Weighted_sell_correlation'].ewm(alpha=alpha).mean()
    data_for_teach_df['CMLTV_WBC'] = data_for_teach_df['Weighted_buy_correlation'].ewm(alpha=alpha).mean()
    data_for_teach_df['CMLTV_WSAC'] = data_for_teach_df['Weighted_sell_anti_correlation'].ewm(alpha=alpha).mean()
    data_for_teach_df['CMLTV_WBAC'] = data_for_teach_df['Weighted_buy_anti_correlation'].ewm(alpha=alpha).mean()


    data_for_teach_df['CMLTV_N_Sell_amount_in_sell_interval'] = data_for_teach_df['Normalized_sell_amount_in_sell_interval'].ewm(alpha=alpha).mean()
    data_for_teach_df['CMLTV_N_Buy_amount_in_buy_interval'] = data_for_teach_df['Normalized_buy_amount_in_buy_interval'].ewm(alpha=alpha).mean()
    data_for_teach_df['CMLTV_SASI-SABI'] = data_for_teach_df['SASI-SABI'].ewm(alpha=alpha).mean()
    data_for_teach_df['CMLTV_BABI-BASI'] = data_for_teach_df['BABI-BASI'].ewm(alpha=alpha).mean()
    data_for_teach_df['CMLTV_WSASI-WSABI'] = data_for_teach_df['WSASI-WSABI'].ewm(alpha=alpha).mean()
    data_for_teach_df['CMLTV_WBABI-WBASI'] = data_for_teach_df['WBABI-WBASI'].ewm(alpha=alpha).mean()
    data_for_teach_df['Action'] = data_for_teach_df['Buy'] - data_for_teach_df['Sell']

    data_for_profit_test_df = data_for_teach_df.loc[
        (data_for_teach_df['Timestamp'] >= profit_test_start_tmsp) &
        (data_for_teach_df['Timestamp'] <= profit_test_end_tmsp)
        ]
    data_for_teach_df = data_for_teach_df.loc[
        data_for_teach_df['Timestamp'] >= teaching_start_tmsp &
        (data_for_teach_df['Timestamp'] <= teaching_end_tmsp)
        ]
    
    if converge_test:
        data_for_teach_df.to_parquet(os.path.join(dir_for_temp_files_of_module, '6_data_for_teach_df.parquet'), index=False)
        data_for_profit_test_df.to_parquet(os.path.join(dir_for_temp_files_of_module, '7_data_for_profit_test_df.parquet'), index=False)
    
    return data_for_teach_df, data_for_profit_test_df

def teach_n_test_data_with_optimized_corrs(txs_ddf, data_for_teach_ddf, tmps):
    cmlt_start_tmsp = tmps['cmlt_start_tmsp']
    cmlt_end_tmsp = tmps['cmlt_end_tmsp']
    teaching_start_tmsp = tmps['teaching_start_tmsp']
    teaching_end_tmsp = tmps['teaching_end_tmsp']
    profit_test_start_tmsp = tmps['profit_test_start_tmsp']
    profit_test_end_tmsp = tmps['profit_test_end_tmsp']
    # Взвешенные корреляции с разделением по типу транзакции:
    # Для продаж используем Normalized_sell_amount без abs(), чтобы сохранить знак (продажи должны быть со знаком)
    txs_ddf['Weighted_cor_NSA_ISI_mean'] = txs_ddf['cor_NSA_ISI_mean'] * txs_ddf['Normalized_sell_amount']  # Изменено: без abs() для продаж
    txs_ddf['Weighted_cor_NSA_IBI_mean'] = txs_ddf['cor_NSA_IBI_mean'] * txs_ddf['Normalized_sell_amount']  # Изменено: без abs() для продаж

    # Для покупок, если Normalized_buy_amount всегда положителен, можно оставить как есть
    txs_ddf['Weighted_cor_NBA_IBI_mean'] = txs_ddf['cor_NBA_IBI_mean'] * txs_ddf['Normalized_buy_amount']   # Изменено: убрано abs() для единообразия
    txs_ddf['Weighted_cor_NBA_ISI_mean'] = txs_ddf['cor_NBA_ISI_mean'] * txs_ddf['Normalized_buy_amount']   # Изменено: убрано abs() для единообразия

    # Нормализация взвешенных коэффициентов на основе максимального абсолютного значения
    max_abs_weighted = txs_ddf[['Weighted_cor_NSA_ISI_mean', 'Weighted_cor_NSA_IBI_mean',
                                'Weighted_cor_NBA_IBI_mean', 'Weighted_cor_NBA_ISI_mean']].abs().max().compute()
    max_abs_weighted_val = max_abs_weighted.max()  
    if max_abs_weighted_val  > 0:
        for col in ['Weighted_cor_NSA_ISI_mean', 'Weighted_cor_NSA_IBI_mean',
                    'Weighted_cor_NBA_IBI_mean', 'Weighted_cor_NBA_ISI_mean']:
            txs_ddf[f'Norm_{col}'] = txs_ddf[col] / max_abs_weighted_val  # Изменено: нормализация на основе взвешенных коэффициентов

    # Логарифмическое сглаживание с использованием нормализованных значений
    # Для продаж сохраняем знак, используя np.sign() и логарифм от модуля
    txs_ddf['Log_Weighted_cor_NSA_ISI_mean'] = txs_ddf['cor_NSA_ISI_mean'] * \
        np.sign(txs_ddf['Normalized_sell_amount']) * np.log1p(np.abs(txs_ddf['Normalized_sell_amount']).fillna(0))  # Изменено: для продаж сохраняем знак
    txs_ddf['Log_Weighted_cor_NSA_IBI_mean'] = txs_ddf['cor_NSA_IBI_mean'] * \
        np.sign(txs_ddf['Normalized_sell_amount']) * np.log1p(np.abs(txs_ddf['Normalized_sell_amount']).fillna(0))  # Изменено: для продаж сохраняем знак

    # Для покупок, если значения всегда положительные, можно оставить без np.sign()
    txs_ddf['Log_Weighted_cor_NBA_IBI_mean'] = txs_ddf['cor_NBA_IBI_mean'] * np.log1p(txs_ddf['Normalized_buy_amount'].fillna(0))   # Изменено
    txs_ddf['Log_Weighted_cor_NBA_ISI_mean'] = txs_ddf['cor_NBA_ISI_mean'] * np.log1p(txs_ddf['Normalized_buy_amount'].fillna(0))   # Изменено

    # Присоединяем временные метки из обучающих данных
    merged_ddf = dd.merge_asof(
        txs_ddf,
        data_for_teach_ddf[['Timestamp']],
        left_on='Block_time',
        right_on='Timestamp',
        direction='nearest'
    )

    merged_ddf['Nearest_tmps_from_learning_data'] = merged_ddf['Timestamp']

    # Функция для определения попадания в 10-минутное окно


    merged_ddf = merged_ddf.map_partitions(calculate_in_10_min_period).persist()

    # Убираем ненужные столбцы (например, Amount)
    merged_ddf = merged_ddf.drop(columns=['Transaction_id', 'Wallet_id', 'Timestamp', 'Block_hash', 'Amount'])  # Изменено: удалён столбец Amount

    # Группировка по ближайшей временной метке
    grouped_ddf = merged_ddf.groupby('Nearest_tmps_from_learning_data').sum().reset_index()

    data_for_teach_ddf = data_for_teach_ddf.merge(
        grouped_ddf,
        left_on='Timestamp',
        right_on='Nearest_tmps_from_learning_data',
        how='left'
    )

    data_for_teach_ddf = data_for_teach_ddf.fillna(0)

    data_for_teach_df = data_for_teach_ddf.compute()  # Преобразуем Dask в Pandas
    del data_for_teach_ddf
    gc.collect()

    # Кумулятивные суммы с экспоненциальным сглаживанием
    time_frame_hours = 3
    tau = time_frame_hours * 6  # (3 часа = 18 строк по 10 минут)
    alpha = 1 - math.exp(-1 / tau)  # коэффициент затухания

    for col in ['Weighted_cor_NSA_ISI_mean', 'Weighted_cor_NSA_IBI_mean',
                'Weighted_cor_NBA_IBI_mean', 'Weighted_cor_NBA_ISI_mean',
                'NSA_ISI_mean', 'NSA_ISI_std', 'NSA_ISI_sum',
                'NBA_IBI_mean', 'NBA_IBI_std', 'NBA_IBI_sum',
                'cor_NSA_ISI_mean', 'cor_NBA_IBI_mean',
                'SASI_SABI_mean', 'BABI_BASI_mean', 'WSASI_WSABI_mean', 'WBABI_WBASI_mean']:
        data_for_teach_df[f'CMLTV_{col}'] = data_for_teach_df[col].ewm(alpha=alpha).mean()

    # Действие (покупка - продажа)
    data_for_teach_df['Action'] = data_for_teach_df['Buy'] - data_for_teach_df['Sell']
    data_for_teach_df = data_for_teach_df.fillna(0)

    data_for_profit_test_df = data_for_teach_df.loc[
        (data_for_teach_df['Timestamp'] >= profit_test_start_tmsp) &
        (data_for_teach_df['Timestamp'] <= profit_test_end_tmsp)
        ]
    data_for_teach_df = data_for_teach_df.loc[
        data_for_teach_df['Timestamp'] >= teaching_start_tmsp &
        (data_for_teach_df['Timestamp'] <= teaching_end_tmsp)
        ]
    
    return data_for_teach_df, data_for_profit_test_df

# АЛЬТЕРНАТИВНЫЙ КОД ДЛЯ get_data_for_teach_with_dask, ПОПРОБОВАТЬ ПОЗЖЕ

# # Здесь оставляем предварительную обработку корреляций для каждого кошелька,
# # вычисляем разности между нормированными суммами в разных интервалах.
# correlation_wallets_df = correlation_wallets_df.reset_index(drop=True)
# correlation_wallets_df = correlation_wallets_df.drop(labels='Normalized_sell_buy_amount', axis=1)
# # # Расчёт разницы нормированных сумм без использования количества транзакций
# correlation_wallets_df['SASI-SABI'] = (correlation_wallets_df['Normalized_sell_amount_in_sell_interval'] -
#                                        correlation_wallets_df['Normalized_sell_amount_in_buy_interval'])
# correlation_wallets_df['BABI-BASI'] = (correlation_wallets_df['Normalized_buy_amount_in_buy_interval'] -
#                                        correlation_wallets_df['Normalized_buy_amount_in_sell_interval'])
# correlation_wallets_df['WSASI-WSABI'] = (correlation_wallets_df['Weighted_sell_correlation'] -
#                                          correlation_wallets_df['Weighted_sell_anti_correlation'])
# correlation_wallets_df['WBABI-WBASI'] = (correlation_wallets_df['Weighted_buy_correlation'] -
#                                          correlation_wallets_df['Weighted_buy_anti_correlation'])

# # Привязываем каждую транзакцию к ближайшему 10-минутному интервалу.
# # Здесь dd.merge_asof используется для сопоставления временной метки транзакции с ближайшей меткой из learning_data.
# txs_df['Nearest_tmps_from_learning_data'] = dd.merge_asof(
#     txs_df, 
#     learning_data[['Timestamp']], 
#     left_on='Block_time', 
#     right_on='Timestamp', 
#     direction='nearest'
# )['Timestamp']

# # Определяем, попадает ли транзакция в 10-минутный интервал (±300 секунд от метки)
# txs_df['in_10_min_period'] = ((txs_df['Block_time'] >= txs_df['Nearest_tmps_from_learning_data'] - 300) &
#                               (txs_df['Block_time'] <= txs_df['Nearest_tmps_from_learning_data'] + 300))
# # Если условие нужно использовать для фильтрации, можно оставить логическое значение, иначе можно преобразовать в числовой формат (0/1)
# # Например: txs_df['in_10_min_period'] = txs_df['in_10_min_period'].astype(int)

# # Группируем по 10-минутным интервалам, агрегируя суммы по взвешенным суммам и нормированным суммам.
# # Обратите внимание: здесь суммируются именно значения сумм, а не количества транзакций,
# # таким образом, знак транзакций (отрицательный для продаж, положительный для покупок) сохраняется.
# grouped_df = txs_df.groupby('Nearest_tmps_from_learning_data').agg({
#     'Weighted_sell_correlation': 'sum',
#     'Weighted_buy_correlation': 'sum',
#     'Weighted_sell_anti_correlation': 'sum',
#     'Weighted_buy_anti_correlation': 'sum',
#     'WSASI-WSABI': 'sum',
#     'WBABI-WBASI': 'sum',
#     'Normalized_sell_amount_in_sell_interval': 'sum',
#     'Normalized_sell_amount_in_buy_interval': 'sum',
#     'Normalized_buy_amount_in_buy_interval': 'sum',
#     'Normalized_buy_amount_in_sell_interval': 'sum',
#     'SASI-SABI': 'sum',
#     'BABI-BASI': 'sum'
# })

# # Объединяем агрегированные данные с learning_data по временной метке
# learning_data = learning_data.merge(
#     grouped_df,
#     left_on='Timestamp',
#     right_on='Nearest_tmps_from_learning_data',
#     how='left'
# )

# # Инициализируем колонки для кумулятивных (экспоненциально взвешенных) сумм.
# learning_data['CMLTV_WSC'] = 0
# learning_data['CMLTV_WBC'] = 0
# learning_data['CMLTV_WSAC'] = 0
# learning_data['CMLTV_WBAC'] = 0
# learning_data['CMLTV_N_Sell_amount_in_sell_interval'] = 0
# learning_data['CMLTV_N_Buy_amount_in_buy_interval'] = 0
# learning_data['CMLTV_SASI-SABI'] = 0
# learning_data['CMLTV_BABI-BASI'] = 0
# learning_data['CMLTV_WSASI-WSABI'] = 0
# learning_data['CMLTV_WBABI-WBASI'] = 0

# # Расчёт коэффициента затухания для экспоненциального сглаживания (3 часа = 18 строк по 10 минут)
# time_frame_hours = 3
# tau = time_frame_hours * 6  # число строк за 3 часа
# alpha = 1 - math.exp(-1 / tau)  # коэффициент затухания

# # Вычисляем экспоненциально взвешенные средние для агрегированных сумм.
# learning_data['CMLTV_WSC'] = learning_data['Weighted_sell_correlation'].ewm(alpha=alpha).mean()
# learning_data['CMLTV_WBC'] = learning_data['Weighted_buy_correlation'].ewm(alpha=alpha).mean()
# learning_data['CMLTV_WSAC'] = learning_data['Weighted_sell_anti_correlation'].ewm(alpha=alpha).mean()
# learning_data['CMLTV_WBAC'] = learning_data['Weighted_buy_anti_correlation'].ewm(alpha=alpha).mean()

# learning_data['CMLTV_N_Sell_amount_in_sell_interval'] = learning_data['Normalized_sell_amount_in_sell_interval'].ewm(alpha=alpha).mean()
# learning_data['CMLTV_N_Buy_amount_in_buy_interval'] = learning_data['Normalized_buy_amount_in_buy_interval'].ewm(alpha=alpha).mean()
# learning_data['CMLTV_SASI-SABI'] = learning_data['SASI-SABI'].ewm(alpha=alpha).mean()
# learning_data['CMLTV_BABI-BASI'] = learning_data['BABI-BASI'].ewm(alpha=alpha).mean()
# learning_data['CMLTV_WSASI-WSABI'] = learning_data['WSASI-WSABI'].ewm(alpha=alpha).mean()
# learning_data['CMLTV_WBABI-WBASI'] = learning_data['WBABI-WBASI'].ewm(alpha=alpha).mean()

# # Вычисляем итоговое действие с учетом направления транзакции: продажи (Amount отрицательные) и покупки (Amount положительные)
# learning_data['Action'] = learning_data['Buy'] - learning_data['Sell'] 

def ensure_dask_dataframe(obj, npartitions=1):
    """
    Превращает переданный объект в Dask DataFrame.
    Если это Future, достаёт реальный объект через .result().
    Если это pandas DataFrame, конвертирует в Dask DataFrame.
    Если это уже Dask DataFrame, возвращает как есть.
    Иначе выбрасывает исключение.
    """
    # Если это Future, достаём реальный результат
    if isinstance(obj, Future):
        obj = obj.result()

    # Если теперь это pandas DataFrame, делаем dd.from_pandas
    if isinstance(obj, pd.DataFrame):
        return dd.from_pandas(obj, npartitions=npartitions)
    # Если это Dask DataFrame — оставляем как есть
    elif isinstance(obj, dd.DataFrame):
        return obj
    else:
        raise TypeError(f"Ожидался pandas DataFrame, Dask DataFrame или Future, а получен тип {type(obj)}.")
    
def clean_data(df):
    print('оставить Timestamp или Nearest_tmps_from_learning_data для построения графика для отладки и справки')
    df = df.drop(columns=['Sell',
            'Buy',
            'Normalized_buy_amount',
            'Normalized_sell_amount',
            'in_buy_interval',
            'in_sell_interval',
            'Human_time', 
            'Timestamp', 
            'Btc_block_time_price',  
            'Block_time',  
            'Block_height',  
            'n',
            'in_10_min_period',
            'Amount',  
            'Transactions_Count',  
            'Normalized_sell_amount_mean',  
            'Normalized_sell_amount_std',  
            'Normalized_buy_amount_mean',  
            'Normalized_buy_amount_std',  
            'in_sell_interval_mean',  
            'in_sell_interval_std',  
            'in_buy_interval_mean',  
            'in_buy_interval_std', 
            'Amount_count', 
            'Amount_<lambda_0>', 
            'Amount_<lambda_1>',  
            'Nearest_tmps_from_learning_data'], errors='ignore')
    
    # print('clean_data before teaching df.head()')
    # print(df.head())
    return df

def get_wallets_of_peaks_list(iterval_with_peaks_df, filter_params):
    logger.info("Start get_wallets_of_peaks_list")
    list_intervals = get_list_of_intervals(iterval_with_peaks_df)
    list_intervals = merge_intervals(list_intervals)
    blocks_of_intervals = get_blocks_of_intervals(list_intervals)

    if filter_params['txs_count_of_wallets']:
        txs_qnt_of_wallets = filter_params['txs_count_of_wallets']
    else:
        txs_qnt_of_wallets = 0

    uniq_wallets_of_blocks = get_uniq_wallets_of_blocks_with_dask(blocks_of_intervals, txs_qnt_of_wallets)

    return uniq_wallets_of_blocks

def get_peaks_of_iteration(start_tmsp, end_tmsp):
    peaks_data = sf.get_peaks_df()
    peaks_data_in_iteration_to_teach = peaks_data.loc[
        (peaks_data['Timestamp']>=start_tmsp) & 
        (peaks_data['Timestamp']<=end_tmsp)
        ]
    return peaks_data_in_iteration_to_teach

def merge_intervals(intervals):
    logger.info("Start merge_intervals")

    # Сортируем интервалы по их началу
    intervals.sort(key=lambda x: x[0])

    merged = []
    for interval in intervals:
        if not merged or merged[-1][1] < interval[0]:
            # Если список пуст или предыдущий интервал не пересекается с текущим,
            # добавляем текущий интервал в результат
            merged.append(interval)
        else:
            # Есть пересечение, объединяем интервалы
            merged[-1][1] = max(merged[-1][1], interval[1])

    return merged

def get_list_of_intervals(btc_price_df_with_intervals):
    logger.info("Start get_list_of_intervals")
    intervals = transform_btc_to_intervals(btc_price_df_with_intervals)
    list_intervals = []
    # print(intervals) 
    for index, row in intervals.iterrows():
        list_intervals.append([int(row['Start']), int(row['End'])])
    return list_intervals

def transform_btc_to_intervals(btc_price_df_with_intervals):
    logger.info("Start transform_btc_to_intervals")
    btc_price_df_with_intervals = btc_price_df_with_intervals.loc[(btc_price_df_with_intervals['Buy'] == 1) | (btc_price_df_with_intervals['Sell'] == 1)]
    timestapms = pd.DataFrame()
    timestapms['Timestamp'] = btc_price_df_with_intervals['Timestamp']
    timestapms['Start'] = timestapms['Timestamp'] - 600
    timestapms['End'] = timestapms['Timestamp'] + 600
    return timestapms

def get_blocks_of_intervals(intervals, table_name='data_table'):
    logger.info("Start get_blocks_of_intervals")

    # Если нечего обрабатывать, возвращаем пустой список
    if not intervals:
        return []

    # 1) Находим глобальный мин/макс по времени:
    global_start = min(interval[0] for interval in intervals)
    global_end = max(interval[1] for interval in intervals)

    # 2) Проверяем, существует ли локальный файл
    if os.path.isfile(BLOCK_HEIGHT_BLOCK_TIME_MAP_DIR_FILE):
        df = pd.read_parquet(BLOCK_HEIGHT_BLOCK_TIME_MAP_DIR_FILE)
        
        # Предполагается, что block_times отсортированы согласно block_heights
        block_times = df['block_times']
        block_heights = df['block_heights']

        # Минимальная и максимальная временные метки, которые есть в файле
        file_min_time = block_times.min()
        file_max_time = block_times.max()

        # 3) Если файл полностью покрывает нужный диапазон времени
        if file_min_time <= global_start and file_max_time >= global_end:
            logger.info("Файл покрывает все интервалы, используем данные из файла.")
            
            # Теперь просто собираем нужные блоки из файла, без запроса в БД
            all_blocks = []
            for (start_time, end_time) in intervals:
                left_index = bisect.bisect_left(block_times, start_time)
                right_index = bisect.bisect_right(block_times, end_time)
                if left_index < right_index:
                    all_blocks.extend(block_heights[left_index:right_index])
            
            return all_blocks
        else:
            logger.info("Файл существует, но не полностью покрывает нужный диапазон. "
                        "Дополняем недостающие данные из БД.")
            return _get_blocks_from_db(intervals, df, table_name)
    else:
        logger.info("Файл не существует, придётся строить карту блоков через БД.")
        return _get_blocks_from_db(intervals, None, table_name)

def _get_blocks_from_db(intervals, existing_df, table_name):
    """
    Логика, аналогичная вашей исходной:
    1) Узнать min_block_height и max_block_height из БД
    2) Построить карту (Block_height -> Block_time), если нет полного покрытия
    3) Сохранить результат в parquet (если нужно)
    4) Вернуть нужные блоки
    """
    db_path = BLOCKS_SQL_DATA
    if isinstance(db_path, Path):
        db_path = str(db_path)

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Находим глобальный min/max Block_height (как в вашем коде)
    cursor.execute(f"SELECT MIN(Block_height), MAX(Block_height) FROM {table_name};")
    result = cursor.fetchone()
    if not result or result[0] is None or result[1] is None:
        cursor.close()
        conn.close()
        return []

    min_block_height, max_block_height = result[0], result[1]

    is_height_time = os.path.isfile(BLOCK_HEIGHT_BLOCK_TIME_MAP_DIR_FILE)
    if is_height_time:
        df = pd.read_parquet(BLOCK_HEIGHT_BLOCK_TIME_MAP_DIR_FILE)
        block_heights = df['block_heights']
        min_df_block = block_heights.min()
        max_df_block = block_heights.max()
        check_for_min_block = min_block_height == min_df_block
        check_for_max_block = max_block_height == max_df_block
    # Теперь у нас есть диапазон [min_block_height, max_block_height]
    # Предполагается, что блоки идут подряд от min до max без пропусков.
    # Для каждого блока получим Block_time.
    if is_height_time:
        if check_for_min_block and check_for_max_block:
            block_times = df['block_times']

    else:
        block_heights = []
        block_times = []

        total_blocks = max_block_height - min_block_height + 1
        count = 0

        for bh in range(min_block_height, max_block_height + 1):
            cursor.execute(f"""
                SELECT Block_time 
                FROM {table_name}
                WHERE Block_height = ?;
            """, (bh,))
            row = cursor.fetchone()
            if row:
                block_time = row[0]
                block_heights.append(bh)
                block_times.append(block_time)

        cursor.close()
        conn.close()
        df = pd.DataFrame({
            'block_heights': block_heights,
            'block_times': block_times
        })
        df.to_parquet(BLOCK_HEIGHT_BLOCK_TIME_MAP_DIR_FILE)
        logger.info('Новый BLOCK_HEIGHT_BLOCK_TIME_MAP_DIR_FILE сохранен')

    all_blocks = []
    for (start_time, end_time) in intervals:
        left_index = bisect.bisect_left(block_times, start_time)
        right_index = bisect.bisect_right(block_times, end_time)
        if left_index < right_index:
            all_blocks.extend(block_heights[left_index:right_index])
    
    cursor.close()
    conn.close()
    return all_blocks

def get_uniq_wallets_of_blocks_with_dask(blocks_of_intervals, N = 0):
    logger.info("Start get_uniq_wallets_of_blocks_with_dask")
    # нужен для ускорения тестирования
    chunk_size = 999
    dask_client = get_dask_client()

    futures = []
    for i in range(0, len(blocks_of_intervals), chunk_size):
        chunk = blocks_of_intervals[i:i+chunk_size]
        future = dask_client.submit(get_counts_of_wallets_for_blocks, chunk)
        futures.append(future)

    results = dask_client.gather(futures)
    combined_counts = {}
    for partial_dict in results:
        for wallet_id, cnt in partial_dict.items():
            combined_counts[wallet_id] = combined_counts.get(wallet_id, 0) + cnt

    filtered_wallets = [w for w, c in combined_counts.items() if c > N]
    close_dask_client(dask_client)

    return filtered_wallets

def get_counts_of_wallets_for_blocks(block_list, table_name='data_table', chunk_size=999):
    db_path = BLOCKS_SQL_DATA
    if isinstance(db_path, Path):
        db_path = str(db_path)

    wallets_with_counts = {}
    with sqlite3.connect(db_path) as conn:
        cursor = conn.cursor()
        placeholders = ",".join("?" * len(block_list))
        query = f"""
            SELECT Wallet_id, COUNT(*) AS tx_count
            FROM {table_name}
            WHERE Block_height IN ({placeholders})
            GROUP BY Wallet_id
        """
        cursor.execute(query, block_list)
        rows = cursor.fetchall()
        for wallet_id, local_count in rows:
            wallets_with_counts[wallet_id] = wallets_with_counts.get(wallet_id, 0) + local_count

    return wallets_with_counts

def get_uniq_wallets_of_blocks(block_list, table_name='data_table', chunk_size=999):
    # logger.info("Start get_uniq_wallets_of_blocks")
    logger.info("МОЖНО ОДНОЙ ТРАНЗАКЦИЕЙ ИЗ БД СОБИРАТЬ ДАННЫЕ НО С ОГРАНИЧЕНИЕМ НА КОЛ-ВО СТРОК, ПОТОМ ДАСКОМ ИХ В ОДИН ДФ")

    db_path = BLOCKS_SQL_DATA
    if isinstance(db_path, Path):
        db_path = str(db_path)

    unique_wallets = set()

    with sqlite3.connect(db_path) as conn:
        cursor = conn.cursor()
        for i in range(0, len(block_list), chunk_size):
            chunk = block_list[i:i+chunk_size]
            if not chunk:
                continue
            placeholders = ",".join("?" * len(chunk))
            query = f"""
                SELECT DISTINCT Wallet_id
                FROM {table_name}
                WHERE Block_height IN ({placeholders});
            """
            try:
                cursor.execute(query, chunk)
                rows = cursor.fetchall()
                unique_wallets.update(r[0] for r in rows)
            except sqlite3.OperationalError as e:
                logger.error(f"Ошибка выполнения SQL запроса: {e}")
                continue  # Можно решить, как обрабатывать такие случаи

    return list(unique_wallets)

def calculate_correlations_of_wallets_old(txs_of_chunk_with_intervals):
    logger.info("Start calculate_correlations_of_wallets")

    # Сгруппируем транзакции по кошельку и применим функцию calculate_correlations
    # print(txs_of_chunk_with_intervals.info())
    txs_of_chunk_with_intervals = txs_of_chunk_with_intervals.reset_index(drop=True)
    grouped = txs_of_chunk_with_intervals.groupby('Wallet_id')
    correlation_data = grouped.apply(calculate_correlations)

    correlation_df = pd.DataFrame(correlation_data).reset_index(drop=True)
    correlation_df = correlation_df.fillna(0.0)

    # Добавляем дополнительные взвешенные корреляции
    correlation_df['Weighted_sell_correlation'] = correlation_df['Normalized_sell_amount_in_sell_interval'] * correlation_df['sell_txs_qnty']
    correlation_df['Weighted_buy_correlation'] = correlation_df['Normalized_buy_amount_in_buy_interval'] * correlation_df['buy_txs_qnty']
    correlation_df['Weighted_sell_anti_correlation'] = correlation_df['Normalized_sell_amount_in_buy_interval'] * correlation_df['sell_txs_qnty']
    correlation_df['Weighted_buy_anti_correlation'] = correlation_df['Normalized_buy_amount_in_sell_interval'] * correlation_df['buy_txs_qnty']
    correlation_df['SASI-SABI'] = correlation_df['Normalized_sell_amount_in_sell_interval']-correlation_df['Normalized_sell_amount_in_buy_interval']
    correlation_df['BABI-BASI'] = correlation_df['Normalized_buy_amount_in_buy_interval']-correlation_df['Normalized_buy_amount_in_sell_interval']
    correlation_df['WSASI-WSABI'] = correlation_df['Weighted_sell_correlation']-correlation_df['Weighted_sell_anti_correlation']
    correlation_df['WBABI-WBASI'] = correlation_df['Weighted_buy_correlation']-correlation_df['Weighted_buy_anti_correlation']
    gc.collect()

    # print(correlation_df.head())
    return correlation_df

def calculate_correlations(group):
    logger.info("Start calculate_correlations")

    correlation_matrix = group[
        ['Normalized_sell_amount', 'Normalized_buy_amount', 'in_sell_interval', 'in_buy_interval']
    ].corr(method='pearson')
    wallet_id = group['Wallet_id'].iloc[0]
    sell_txs = len(group.loc[group['Amount'] < 0])
    buy_txs = len(group.loc[group['Amount'] > 0])
    result = pd.Series([
        wallet_id,
        correlation_matrix.loc['Normalized_sell_amount', 'in_sell_interval'],
        correlation_matrix.loc['Normalized_sell_amount', 'in_buy_interval'],
        correlation_matrix.loc['Normalized_buy_amount', 'in_buy_interval'],
        correlation_matrix.loc['Normalized_buy_amount', 'in_sell_interval'],
        sell_txs,
        buy_txs
    ], index=[
        'Wallet_id',
        'Normalized_sell_amount_in_sell_interval',
        'Normalized_sell_amount_in_buy_interval',
        'Normalized_buy_amount_in_buy_interval',
        'Normalized_buy_amount_in_sell_interval',
        'sell_txs_qnty', 
        'buy_txs_qnty'
    ])
    gc.collect()
    return result

def import_peak_intervals(txs_of_chunk, peaks_data):
    # logger.info("Start import_peak_intervals")

    # Предполагается, что txs_of_chunk отсортирован по 'Block_time', иначе:
    txs_of_chunk = txs_of_chunk.sort_values('Block_time')



    temp_buy = peaks_data[peaks_data['Buy'] > 0]['Timestamp'].values
    temp_sell = peaks_data[peaks_data['Sell'] > 0]['Timestamp'].values

    txs_of_chunk['in_sell_interval'] = 0
    txs_of_chunk['in_buy_interval'] = 0
    
    block_time = txs_of_chunk['Block_time'].values

    in_sell = txs_of_chunk['in_sell_interval'].values
    in_buy = txs_of_chunk['in_buy_interval'].values

    for tmsp in temp_sell:
        start = tmsp - 300
        end = tmsp + 300
        left = np.searchsorted(block_time, start, side='left')
        right = np.searchsorted(block_time, end, side='right')
        in_sell[left:right] = -1

    for tmsp in temp_buy:
        start = tmsp - 300
        end = tmsp + 300
        left = np.searchsorted(block_time, start, side='left')
        right = np.searchsorted(block_time, end, side='right')
        in_buy[left:right] = 1

    txs_of_chunk['in_sell_interval'] = in_sell
    txs_of_chunk['in_buy_interval'] = in_buy

    # print('_______txs_of_chunk, import_peak_intervals')
    # print(txs_of_chunk.head())
    # print(txs_of_chunk.loc[txs_of_chunk['in_sell_interval']!=0].head())
    # print(txs_of_chunk.loc[txs_of_chunk['in_buy_interval']!=0].head())

    del block_time, in_sell, in_buy
    gc.collect()

    # if not txs_of_chunk.loc[txs_of_chunk['in_sell_interval'] != 0].empty:
    #     print(txs_of_chunk.loc[txs_of_chunk['in_sell_interval'] != 0].head())
# not in interval:
# Transaction_id                                                                      Wallet_id                    Btc_block_time_price  Block_time  Block_height    Block_hash     n  Amount  Transactions_Count  Normalized_buy_amount  Normalized_sell_amount  in_sell_interval  in_buy_interval
# 6712f93e82bad0e17e7bc1974ad465a272ffca37528de79690d2239b3a4cc9e8  bc1qrp3h5dkkg4y78y9dyrt8ue4l3857nxjerllsy6             27227.240  1697026514        811700  000000000000a2803   613   0.006                   1                  0.674                   0.000                 0                0
   
# in sell interval:   
#  Transaction_id                                                      Wallet_id               Btc_block_time_price    Block_time  Block_height   Block_hash    n  Amount  Transactions_Count  Normalized_buy_amount  Normalized_sell_amount  in_sell_interval  in_buy_interval
# 645946953a4ea7ae3c46c80efab367ba97f82e0d88e9a9ab835c78c513b88186  3EH61G3wYnpz2ocJkShXeADJZVHT2ek5qv     34640.660  1698116226        813577  000000000243   72   0.005                   1                  0.094                   0.000                -1                0
   
    return txs_of_chunk

def normalize_amount(txs_of_chunk):
    # logger.info("Start normalize_amount")
    # print(txs_of_chunk.head())
    normalized_chunk = txs_of_chunk.groupby('Wallet_id').apply(normalize).reset_index(drop=True)
    normalized_chunk['Normalized_sell_amount'] = normalized_chunk['Normalized_sell_amount'].fillna(0.0)
    normalized_chunk['Normalized_buy_amount'] = normalized_chunk['Normalized_buy_amount'].fillna(0.0)
    del txs_of_chunk
    return normalized_chunk

def min_max_normalize_shift(series):
    min_val = series.min()
    max_val = series.max()
    if min_val == max_val:
        return pd.Series([float(0)] * len(series), index=series.index)
    normalized = (series - min_val) / (max_val - min_val)
    return normalized

def normalize(group):
    # logger.info("Start normalize")

    group = group.copy()  # чтобы избежать SettingWithCopy
    positive = group[group['Amount'] > 0]
    negative = group[group['Amount'] < 0]
    
    # Инициализируем столбцы, если их ещё нет
    if 'Normalized_buy_amount' not in group.columns:
        group['Normalized_buy_amount'] = 0.0
    if 'Normalized_sell_amount' not in group.columns:
        group['Normalized_sell_amount'] = 0.0

    if len(positive) > 0:
        # Применяем нормализацию к подмножеству positive и записываем результаты обратно
        norm_buy = min_max_normalize_shift(positive['Amount'])
        group.loc[positive.index, 'Normalized_buy_amount'] = norm_buy
        
    if len(negative) > 0:
        norm_sell = min_max_normalize_shift(negative['Amount'])
        # Знак минус, как задумано
        group.loc[negative.index, 'Normalized_sell_amount'] = -norm_sell

    del positive, negative
    # print('group')
    # print(group.head(10))
#      Transaction_id       Wallet_id         Btc_block_time_price  Block_time  Block_height       Block_hash    n  Amount  Transactions_Count  Normalized_buy_amount  Normalized_sell_amount
# 51157  45cd0820de518cb  bc1qcx6lzt0tq2q             26267.420  1695830992        809602  0000000000005fea0e   81   0.053                   1                  0.995                   0.000
# 51158  befbb5c1         bc1qcx6lzt0tq2q             26245.880  1695840681        809613  0000000000005fea0e  217   0.006                   1                  0.104                   0.000
# 51159  1b16453076b      bc1qcx6lzt0tq2q             26234.990  1695845148        809623  0000000000005fea0e   81  -0.053                   1                  0.000                  -0.005
# 51160  f3275a57         bc1qcx6lzt0tq2q             26329.670  1695871420        809664  0000000000005fea0e  217  -0.006                   1                  0.000                  -0.896
# 51161  b2d544933        bc1qcx6lzt0tq2q             27070.420  1695917406        809761  0000000000005fea0e   43   0.010                   1                  0.197                   0.000
# 51162  19ce86505b4f     bc1qcx6lzt0tq2q             26896.400  1695955330        809811  0000000000005fea0e   43  -0.010                   1                  0.000                  -0.803
# 51163  c298f2268950     bc1qcx6lzt0tq2q             26918.580  1696079840        810019  0000000000005fea0e  188   0.003                   1                  0.059                   0.000
# 51164  9df7d83780       bc1qcx6lzt0tq2q             27969.150  1696216504        810239  0000000000005fea0e  113   0.017                   1                  0.329                   0.000
# 51165  6809db5098240    bc1qcx6lzt0tq2q             28054.560  1696220859        810248  0000000000005fea0e  188  -0.003                   1                  0.000                  -0.941
# 51166  680db509866240   bc1qcx6lzt0tq2q             28054.560  1696220859        810248  0000000000005fea0e  113  -0.017                   1                  0.000                  -0.67
    return group

def filter_txs_of_chunk(txs_of_chunk, half_of_teaching_period, end_teaching_tmsp):
    # logger.info("Start filter_txs_of_chunk")
    # Transaction_id Wallet_id  Btc_block_time_price Block_time  Block_height Block_hash n  Amount  Transactions_Count
    grouped_by_wallets_df = txs_of_chunk.groupby('Wallet_id').agg({
        'Amount': lambda x: x.abs().sum(),
        'Block_time': 'max'
        })
    
    if half_of_teaching_period is not None:
        filtered_aggregated_ddf = grouped_by_wallets_df[
            (grouped_by_wallets_df['Amount'] >= TOTAL_AMOUNT_MORE_THAN_BTC) & 
            (grouped_by_wallets_df['Block_time'] >= (end_teaching_tmsp - half_of_teaching_period))
        ]
    else:
        filtered_aggregated_ddf = grouped_by_wallets_df[
            (grouped_by_wallets_df['Amount'] >= TOTAL_AMOUNT_MORE_THAN_BTC)
        ]
        
    txs_of_chunk = txs_of_chunk[txs_of_chunk['Wallet_id'].isin(filtered_aggregated_ddf.index)]
    del grouped_by_wallets_df, filtered_aggregated_ddf
    return txs_of_chunk

def get_chunks_of_wallets(wallets_list, chunk_size):
    logger.info("Start get_chunks_of_wallets")

    chunk_list = []
    for i in range(0, len(wallets_list), chunk_size):
        chunk = wallets_list[i:i+chunk_size]
        chunk_list.append(chunk)
    return chunk_list

def get_txs_of_wallets_list_between_blocks(wallet_list, min_block, max_block, chunk_size = 500, table_name='data_table'):
    """
    Получает транзакции для списка кошельков, фильтруя их по диапазону высот блоков.
    
    Параметры:
    - wallet_list (list): Список Wallet_id для выборки.
    - min_block (int): Минимальная высота блока.
    - max_block (int): Максимальная высота блока.
    - table_name (str): Имя таблицы в базе данных.
    
    Возвращает:
    - pd.DataFrame: DataFrame с транзакциями, удовлетворяющими критериям.
    """
    # logger.info("Start get_txs_of_wallets_list")

    db_path = BLOCKS_SQL_DATA
    if isinstance(db_path, Path):
        db_path = str(db_path)

    if not wallet_list:
        logger.warning("Empty wallet_list provided.")
        return pd.DataFrame()

    frames = []

    with sqlite3.connect(db_path) as conn:
        sf.set_sqlite_pragma(conn)
        cursor = conn.cursor() 
        for i in range(0, len(wallet_list), chunk_size):
            chunk = wallet_list[i:i + chunk_size]
            if not chunk:
                continue
            placeholders_wallet = ",".join("?" * len(chunk))
            query = f"""
                SELECT *
                FROM {table_name}
                WHERE Wallet_id IN ({placeholders_wallet})
                AND Block_height BETWEEN ? AND ?;
            """
            # Добавляем min_block и max_block к параметрам запроса
            params = chunk + [min_block, max_block]
            try:
                logger.debug("Executing query: %s", query)
                logger.debug("Params: %s", params)
                cursor.execute(query, params)
                rows = cursor.fetchall()
                column_names = [desc[0] for desc in cursor.description]
                df_chunk = pd.DataFrame(rows, columns=column_names)
                if not df_chunk.empty:
                    frames.append(df_chunk)
                else:
                    print(f"Empty chunk {i//chunk_size + 1}")
                    print(chunk[:10])
                # logger.info(f"Processed chunk {i//chunk_size + 1} / ~{(len(wallet_list)//len(chunk))+1} with {len(chunk)} Wallet_id.")
            except sqlite3.OperationalError as e:
                logger.error(f"SQL query failed for chunk {i//chunk_size + 1}: {e}")
                continue

    if frames:
        df = pd.concat(frames, ignore_index=True)
        df = df.sort_values('Block_time')
    else:
        df = pd.DataFrame()
    del frames
    gc.collect()
    return df

def get_last_block_info(table_name: str = "data_table") -> tuple:
    """
    Возвращает (max_block_height, block_time_of_that_block).
    - max_block_height: int
    - block_time_of_that_block: int 
    
    Параметры:
    ----------
    db_path : str
        Путь к файлу базы данных SQLite.
    table_name : str
        Таблица, в которой хранятся блоки (или транзакции).
        
    Примечания:
    ----------
    Предполагается, что в таблице есть колонки:
      1) Block_height — уникальная высота блока (INT).
      2) Block_time   — временная метка (TIMESTAMP/INT/REAL).
    """
    db_path = BLOCKS_SQL_DATA
    if isinstance(db_path, Path):
        db_path = str(db_path)

    with sqlite3.connect(db_path) as conn:
        cursor = conn.cursor()

        # 1) Получаем максимальный Block_height
        query_max_height = f"""
            SELECT MAX(Block_height)
            FROM {table_name}
        """
        cursor.execute(query_max_height)
        result = cursor.fetchone()
        if not result or result[0] is None:
            return None, None

        max_block_height = result[0]

        # 2) Получаем одну любую строку по этому max_block_height
        query_for_block = f"""
            SELECT Block_height, Block_time 
            FROM {table_name}
            WHERE Block_height = ?
            LIMIT 1
        """
        cursor.execute(query_for_block, (max_block_height,))
        row = cursor.fetchone()
        if not row:
            return None, None

        # row = (Block_height, Block_time)
        return row[0], row[1]  # (int, int|float)
    
def get_yesterday_midnight():
    # Определяем полночь сегодня 
    now = datetime.now()
    today_midnight = datetime(now.year, now.month, now.day)
    today_midnight = int(today_midnight.timestamp())
    return today_midnight

def get_txs_of_wallets_by_tmsp(wallets_chunk, start_test_profit_tmsp, last_test_profit_tmsp, table_name='data_table'):
    logger.info("Start get_txs_of_wallets_by_tmsp")

    placeholders = ', '.join('?' for _ in wallets_chunk)
    query = f"""
        SELECT *
        FROM {table_name}
        WHERE Wallet_id IN ({placeholders})
          AND Timestamp BETWEEN ? AND ?;
    """
    params = wallets_chunk + [start_test_profit_tmsp, last_test_profit_tmsp]
    with sqlite3.connect(BLOCKS_SQL_DATA) as conn:
        txs = pd.read_sql_query(query, conn, params=params)
    return txs

def get_start_teaching_tmsp(model):
    max_block_height, last_block_time = get_last_block_info()
    tmsp = last_block_time -(model.time_params['training_data_duration_months']+model.time_params['total_testing_period_months'])*sf.get_secs_in_month()
    return tmsp

def get_start_n_end_profit_test_tmsp(model, iterval_with_peaks_df):
    start_test_profit_tmsp = iterval_with_peaks_df['Timestamp'].iloc[-1] - model.time_params['time_to_get_cmlt_month']*sf.get_secs_in_month()
    last_test_profit_tmsp = int(start_test_profit_tmsp+model.time_params['model_relevance_period_months']*sf.get_secs_in_month())
    return start_test_profit_tmsp, last_test_profit_tmsp

def make_empty_correlation_df(meta_correlation):
    return pd.DataFrame(meta_correlation)

def make_empty_txs_df() -> pd.DataFrame:
    """
    Создаёт пустой DataFrame, имитирующий структуру txs_of_chunk_with_intervals,
    чтобы при отсутствии данных Dask не ругался на несовпадение meta.
    """
    return pd.DataFrame({
        "Transaction_id": pd.Series(dtype="object"),
        "Wallet_id": pd.Series(dtype="object"),
        "Btc_block_time_price": pd.Series(dtype="float64"),
        "Block_time": pd.Series(dtype="int64"),
        "Block_height": pd.Series(dtype="int64"),
        "Block_hash": pd.Series(dtype="object"),
        "n": pd.Series(dtype="int64"),
        "Amount": pd.Series(dtype="float64"),
        "Transactions_Count": pd.Series(dtype="int64"),
        "Normalized_buy_amount": pd.Series(dtype="float64"),
        "Normalized_sell_amount": pd.Series(dtype="float64"),
        "in_sell_interval": pd.Series(dtype="int64"),
        "in_buy_interval": pd.Series(dtype="int64")
    })

# def get_data_for_teach_with_dask_old(tmps, all_txs_of_wallets_ddf, correlation_wallets_ddf):
#     print(correlation_wallets_ddf.head(1))
#     cmlt_start_tmsp = tmps['cmlt_start_tmsp']
#     teaching_end_tmsp = tmps['teaching_end_tmsp']
#     interval_with_peaks_df = get_peaks_of_iteration(cmlt_start_tmsp, teaching_end_tmsp)
#     print('interval_with_peaks_df')
#     print(interval_with_peaks_df.head(1))
#     print(interval_with_peaks_df.tail(1))
#     print('all_txs_of_wallets_ddf')
#     print(all_txs_of_wallets_ddf.head(1))
#     print(all_txs_of_wallets_ddf.tail(1))
#     data_for_teach = interval_with_peaks_df.drop(labels=['Trade', 'Start_interval', 'End_interval'], axis=1)


#     data_for_teach_ddf = dd.from_pandas(data_for_teach, npartitions=1)
#     del data_for_teach
#     # print('ensure_dask_dataframe')
#     all_txs_of_wallets_ddf = ensure_dask_dataframe(all_txs_of_wallets_ddf)
#     correlation_wallets_ddf = ensure_dask_dataframe(correlation_wallets_ddf)
#     print('correlation_wallets_ddf')
#     print(correlation_wallets_ddf.partitions[0].compute().head(3))

#     txs_ddf = all_txs_of_wallets_ddf.merge(correlation_wallets_ddf, on='Wallet_id', how='left')
#     txs_ddf = txs_ddf.sort_values('Block_time').persist()

#     print('txs_ddf = all_txs_of_wallets_ddf.merge(correlation_wallets_ddf)') 
#     print(txs_ddf.head(3))
# #ind  Transaction_id        Wallet_id       Btc_block_time_price  Block_time  Block_height   Block_hash  n  Amount  Transactions_Count  Normalized_buy_amount  Normalized_sell_amount  Normalized_sell_amount_mean  Normalized_sell_amount_std  Normalized_buy_amount_mean  Normalized_buy_amount_std  in_sell_interval_mean  in_sell_interval_std  in_buy_interval_mean  in_buy_interval_std  Amount_count  Amount_<lambda_0>  Amount_<lambda_1>  NSA_ISI_mean  NSA_ISI_std  NSA_ISI_sum  NSA_IBI_mean  NSA_IBI_std  NSA_IBI_sum  NBA_IBI_mean  NBA_IBI_std  NBA_IBI_sum  NBA_ISI_mean  NBA_ISI_std  NBA_ISI_sum  cor_NSA_ISI_mean  cor_NSA_IBI_mean  cor_NBA_IBI_mean  cor_NBA_ISI_mean  Weighted_sell_correlation_mean  Weighted_buy_correlation_mean  Weighted_sell_anti_correlation_mean  Weighted_buy_anti_correlation_mean  SASI_SABI_mean  BABI_BASI_mean  WSASI_WSABI_mean  WBABI_WBASI_mean
# #51745  d215f22e8d4   p2dj8nw8g4ewg08jzmgy3cy    26515.720         1695813835   809568      00000971103  1 -25.031                   1                  0.000                  -0.833                       -0.646                       0.462                       0.017                      0.049                 -0.017                 0.127                 0.022                0.147    338603.000         224718.000         113885.000         0.011        0.101     3595.439        -0.014        0.118    -4892.648         0.000        0.007      130.039        -0.000        0.007     -101.302            -0.001            -0.001            -0.001            -0.002                        -166.002                        -77.708                             -249.761                            -194.462           0.000           0.001            83.759           116.754

#     # добавляю взвешенную корреляцию от суммы сделок кошельков

#     merged_ddf = dd.merge_asof(
#         txs_ddf,
#         data_for_teach_ddf[['Timestamp']],
#         left_on='Block_time',
#         right_on='Timestamp',
#         direction='nearest'
#         )

#     print(' merged_ddf = dd.merge_asof')
#     print(merged_ddf.head())

#     merged_ddf['Nearest_tmps_from_learning_data'] = merged_ddf['Timestamp']
#     print("merged_ddf[Nearest_tmps_from_learning_data] = merged_ddf[Timestamp)")
#     print(merged_ddf.head())

#     def calculate_in_10_min_period(df):
#         df['in_10_min_period'] = (
#             (df['Block_time'] >= (df['Nearest_tmps_from_learning_data'] - 300)) &
#             (df['Block_time'] <= (df['Nearest_tmps_from_learning_data'] + 300))
#         )
#         return df

#     merged_ddf = merged_ddf.map_partitions(calculate_in_10_min_period)
#     print('map_partitions(calculate_in_10_min_period)')
#     print(merged_ddf.head())

#     merged_ddf = merged_ddf.persist()

#     merged_ddf = merged_ddf.drop(labels=['Transaction_id', 'Wallet_id', 'Timestamp', 'Block_hash', ], axis=1) #,'Number of trades'
#     # print(merged_ddf.partitions[0].compute().head(10))

#     grouped_ddf = merged_ddf.groupby('Nearest_tmps_from_learning_data').sum().reset_index()

#     data_for_teach_ddf = data_for_teach_ddf.merge(
#         grouped_ddf,
#         left_on='Timestamp',
#         right_on='Nearest_tmps_from_learning_data',
#         how='left'
#     )

#     data_for_teach_ddf = data_for_teach_ddf.fillna(0)
#     data_for_teach_ddf['CMLTV_WSC'] = 0
#     data_for_teach_ddf['CMLTV_WBC'] = 0
#     data_for_teach_ddf['CMLTV_WSAC'] = 0
#     data_for_teach_ddf['CMLTV_WBAC'] = 0

#     data_for_teach_ddf['CMLTV_N_Sell_amount_in_sell_interval'] = 0
#     data_for_teach_ddf['CMLTV_N_Buy_amount_in_buy_interval'] = 0
#     data_for_teach_ddf['CMLTV_SASI-SABI'] = 0
#     data_for_teach_ddf['CMLTV_BABI-BASI'] = 0
#     data_for_teach_ddf['CMLTV_WSASI-WSABI'] = 0
#     data_for_teach_ddf['CMLTV_WBABI-WBASI'] = 0

#     logger.info("Start compute data_for_teach_ddf")
#     data_for_teach_df = data_for_teach_ddf.compute()
#     del data_for_teach_ddf
#     gc.collect()
#     data_for_teach_df = data_for_teach_df.sort_values('Timestamp')

# # !!!! потом вынести в настройки
#     # период затухания куммулятивных сумм
#     time_frame_hours = 3
#     tau = time_frame_hours*6  # количество строк за 3 часа (3 часа = 18 строк по 10 минут)
#     alpha = 1 - math.exp(-1 / tau) # коэффициент затухания

#     data_for_teach_df['CMLTV_WSC'] = data_for_teach_df['Weighted_sell_correlation_mean'].ewm(alpha=alpha).mean()
#     data_for_teach_df['CMLTV_WBC'] = data_for_teach_df['Weighted_buy_correlation_mean'].ewm(alpha=alpha).mean()
#     data_for_teach_df['CMLTV_WSAC'] = data_for_teach_df['Weighted_sell_anti_correlation_mean'].ewm(alpha=alpha).mean()
#     data_for_teach_df['CMLTV_WBAC'] = data_for_teach_df['Weighted_buy_anti_correlation_mean'].ewm(alpha=alpha).mean()

#     data_for_teach_df['CMLTV_NSA_ISI_mean'] = data_for_teach_df['NSA_ISI_mean'].ewm(alpha=alpha).mean()
#     data_for_teach_df['CMLTV_NSA_ISI_std'] = data_for_teach_df['NSA_ISI_std'].ewm(alpha=alpha).mean()
#     data_for_teach_df['CMLTV_NSA_ISI_cv'] = data_for_teach_df['CMLTV_NSA_ISI_std'] / data_for_teach_df['CMLTV_NSA_ISI_mean']
#     data_for_teach_df['CMLTV_NSA_ISI_sum'] = data_for_teach_df['NSA_ISI_sum'].ewm(alpha=alpha).mean()

#     data_for_teach_df['CMLTV_NBA_IBI_mean'] = data_for_teach_df['NBA_IBI_mean'].ewm(alpha=alpha).mean()
#     data_for_teach_df['CMLTV_NBA_IBI_std'] = data_for_teach_df['NBA_IBI_std'].ewm(alpha=alpha).mean()
#     data_for_teach_df['CMLTV_NBA_IBI_cv'] = data_for_teach_df['CMLTV_NBA_IBI_std'] / data_for_teach_df['CMLTV_NBA_IBI_mean']
#     data_for_teach_df['CMLTV_NBA_IBI_sum'] = data_for_teach_df['NBA_IBI_sum'].ewm(alpha=alpha).mean()

#     data_for_teach_df['cor_NSA_ISI_mean'] = data_for_teach_df['cor_NSA_ISI_mean'].ewm(alpha=alpha).mean()
#     data_for_teach_df['cor_NBA_IBI_mean'] = data_for_teach_df['cor_NBA_IBI_mean'].ewm(alpha=alpha).mean()

#     data_for_teach_df['CMLTV_SASI_SABI'] = data_for_teach_df['SASI_SABI_mean'].ewm(alpha=alpha).mean()
#     data_for_teach_df['CMLTV_BABI_BASI'] = data_for_teach_df['BABI_BASI_mean'].ewm(alpha=alpha).mean()
#     data_for_teach_df['CMLTV_WSASI_WSABI'] = data_for_teach_df['WSASI_WSABI_mean'].ewm(alpha=alpha).mean()
#     data_for_teach_df['CMLTV_WBABI_WBASI'] = data_for_teach_df['WBABI_WBASI_mean'].ewm(alpha=alpha).mean()

#     data_for_teach_df['Action'] = data_for_teach_df['Buy'] - data_for_teach_df['Sell']
#     # data_for_teach = data_for_teach.merge(grouped_df, left_on='Timestamp', right_on='Nearest_tmps_from_learning_data' ,how='left')
#     data_for_teach_df = data_for_teach_df.fillna(0)

#     return data_for_teach_df

# def get_data_for_test_with_pandas(interval_with_peaks_df, all_txs_of_wallets_ddf, correlation_wallets_ddf):
#     data_for_teach = interval_with_peaks_df.drop(labels=['Trade', 'Start_interval', 'End_interval'], axis=1)
#     print('print(data_for_teach.head())')
#     data_for_teach.to_excel('print(data_for_teachhead()).xlsx')
#     print(data_for_teach.head())

#     data_for_teach_ddf = dd.from_pandas(data_for_teach, npartitions=1)

#     # print('ensure_dask_dataframe')
#     all_txs_of_wallets_ddf = ensure_dask_dataframe(all_txs_of_wallets_ddf)
#     # print(all_txs_of_wallets_ddf.head())
#     correlation_wallets_ddf = ensure_dask_dataframe(correlation_wallets_ddf)
#     # print(correlation_wallets_ddf.head())
#     # print(correlation_wallets_ddf.partitions[0].compute().head(10))


#     txs_ddf = all_txs_of_wallets_ddf.merge(correlation_wallets_ddf, on='Wallet_id', how='left')
#     txs_ddf = txs_ddf.sort_values('Block_time').persist()
#     # print('txs_ddf = all_txs_of_wallets_ddf.merge(correlation_wallets_ddf,') 
#     # print(txs_ddf.head())


#     merged_ddf = dd.merge_asof(
#         txs_ddf,
#         data_for_teach_ddf[['Timestamp']],
#         left_on='Block_time',
#         right_on='Timestamp',
#         direction='nearest'
#         )

#     # print(' merged_ddf = dd.merge_asof')
#     # print(merged_ddf.head())

#     merged_ddf['Nearest_tmps_from_learning_data'] = merged_ddf['Timestamp']
#     # print("merged_ddf[Nearest_tmps_from_learning_data] = merged_ddf[Timestamp)")
#     # print(merged_ddf.head())

#     def calculate_in_10_min_period(df):
#         df['in_10_min_period'] = (
#             (df['Block_time'] >= (df['Nearest_tmps_from_learning_data'] - 300)) &
#             (df['Block_time'] <= (df['Nearest_tmps_from_learning_data'] + 300))
#         )
#         return df

#     merged_ddf = merged_ddf.map_partitions(calculate_in_10_min_period)
#     # print('map_partitions(calculate_in_10_min_period)')
#     # print(merged_ddf.head())

#     merged_ddf = merged_ddf.persist()

#     merged_ddf = merged_ddf.drop(labels=['Transaction_id', 'Wallet_id', 'Timestamp', 'Block_hash', ], axis=1) #,'Number of trades'
#     # print(merged_ddf.partitions[0].compute().head(10))

#     grouped_ddf = merged_ddf.groupby('Nearest_tmps_from_learning_data').sum().reset_index()

#     data_for_teach_ddf = data_for_teach_ddf.merge(
#         grouped_ddf,
#         left_on='Timestamp',
#         right_on='Nearest_tmps_from_learning_data',
#         how='left'
#     )

#     data_for_teach_ddf = data_for_teach_ddf.fillna(0)
#     data_for_teach_ddf['CMLTV_WSC'] = 0
#     data_for_teach_ddf['CMLTV_WBC'] = 0
#     data_for_teach_ddf['CMLTV_WSAC'] = 0
#     data_for_teach_ddf['CMLTV_WBAC'] = 0

#     data_for_teach_ddf['CMLTV_N_Sell_amount_in_sell_interval'] = 0
#     data_for_teach_ddf['CMLTV_N_Buy_amount_in_buy_interval'] = 0
#     data_for_teach_ddf['CMLTV_SASI-SABI'] = 0
#     data_for_teach_ddf['CMLTV_BABI-BASI'] = 0
#     data_for_teach_ddf['CMLTV_WSASI-WSABI'] = 0
#     data_for_teach_ddf['CMLTV_WBABI-WBASI'] = 0

#     logger.info("Start compute data_for_teach_ddf")
#     data_for_teach_df = data_for_teach_ddf.compute()
#     del data_for_teach_ddf
#     gc.collect()
#     data_for_teach_df = data_for_teach_df.sort_values('Timestamp')

#     # период затухания куммулятивных сумм
#     time_frame_hours = 3
#     tau = time_frame_hours*6  # количество строк за 3 часа (3 часа = 18 строк по 10 минут)
#     alpha = 1 - math.exp(-1 / tau) # коэффициент затухания

#     data_for_teach_df['CMLTV_WSC'] = data_for_teach_df['Weighted_sell_correlation_mean'].ewm(alpha=alpha).mean()
#     data_for_teach_df['CMLTV_WBC'] = data_for_teach_df['Weighted_buy_correlation_mean'].ewm(alpha=alpha).mean()
#     data_for_teach_df['CMLTV_WSAC'] = data_for_teach_df['Weighted_sell_anti_correlation_mean'].ewm(alpha=alpha).mean()
#     data_for_teach_df['CMLTV_WBAC'] = data_for_teach_df['Weighted_buy_anti_correlation_mean'].ewm(alpha=alpha).mean()

#     data_for_teach_df['CMLTV_NSA_ISI_mean'] = data_for_teach_df['NSA_ISI_mean'].ewm(alpha=alpha).mean()
#     data_for_teach_df['CMLTV_NSA_ISI_std'] = data_for_teach_df['NSA_ISI_std'].ewm(alpha=alpha).mean()
#     data_for_teach_df['CMLTV_NSA_ISI_cv'] = data_for_teach_df['CMLTV_NSA_ISI_std'] / data_for_teach_df['CMLTV_NSA_ISI_mean']
#     data_for_teach_df['CMLTV_NSA_ISI_sum'] = data_for_teach_df['NSA_ISI_sum'].ewm(alpha=alpha).mean()

#     data_for_teach_df['CMLTV_NBA_IBI_mean'] = data_for_teach_df['NBA_IBI_mean'].ewm(alpha=alpha).mean()
#     data_for_teach_df['CMLTV_NBA_IBI_std'] = data_for_teach_df['NBA_IBI_std'].ewm(alpha=alpha).mean()
#     data_for_teach_df['CMLTV_NBA_IBI_cv'] = data_for_teach_df['CMLTV_NBA_IBI_std'] / data_for_teach_df['CMLTV_NBA_IBI_mean']
#     data_for_teach_df['CMLTV_NBA_IBI_sum'] = data_for_teach_df['NBA_IBI_sum'].ewm(alpha=alpha).mean()

#     data_for_teach_df['cor_NSA_ISI_mean'] = data_for_teach_df['cor_NSA_ISI_mean'].ewm(alpha=alpha).mean()
#     data_for_teach_df['cor_NBA_IBI_mean'] = data_for_teach_df['cor_NBA_IBI_mean'].ewm(alpha=alpha).mean()

#     data_for_teach_df['CMLTV_SASI_SABI'] = data_for_teach_df['SASI_SABI_mean'].ewm(alpha=alpha).mean()
#     data_for_teach_df['CMLTV_BABI_BASI'] = data_for_teach_df['BABI_BASI_mean'].ewm(alpha=alpha).mean()
#     data_for_teach_df['CMLTV_WSASI_WSABI'] = data_for_teach_df['WSASI_WSABI_mean'].ewm(alpha=alpha).mean()
#     data_for_teach_df['CMLTV_WBABI_WBASI'] = data_for_teach_df['WBABI_WBASI_mean'].ewm(alpha=alpha).mean()

#     data_for_teach_df['Action'] = data_for_teach_df['Buy'] - data_for_teach_df['Sell']
#     # data_for_teach = data_for_teach.merge(grouped_df, left_on='Timestamp', right_on='Nearest_tmps_from_learning_data' ,how='left')
#     data_for_teach_df = data_for_teach_df.fillna(0)
#     # print(data_for_teach_df.loc[data_for_teach_df['Action'] == 1].head())
#     # print(data_for_teach_df.loc[data_for_teach_df['Action'] == -1].head())
#     # print(data_for_teach_df.loc[data_for_teach_df['Action'] == 0].head())

#     return data_for_teach_df

# # def get_data_to_test(model, tmps, corelation_of_wallets_df):
#     logger.info("\033[34mStart get_data_to_test\033[0m")
#     peaks_data = sf.get_peaks_df()

#     peaks_data = peaks_data.loc[
#         (peaks_data['Timestamp']>start_test_profit_tmsp_with_cmlt) & 
#         (peaks_data['Timestamp']<last_test_profit_tmsp)]

#     wallets = corelation_of_wallets_df['Wallet_id'].to_list()
#     # print('len(wallets) in get_data_to_test')
#     # print(len(wallets))

#     chunk_size = 999
#     wallets_list = [wallets[i:i + chunk_size] for i in range(0, len(wallets), chunk_size)]
#     correletaion_in_tmsps_df = []
#     #txs_of_chunk = get_txs_of_wallets_by_tmsp(wallets_chunk, start_test_profit_tmsp, last_test_profit_tmsp)
#     blocks_time = pd.read_parquet(BLOCK_HEIGHT_BLOCK_TIME_MAP_DIR_FILE)
#     blocks_time = blocks_time.loc[(blocks_time['block_times']>=start_test_profit_tmsp_with_cmlt) & (blocks_time['block_times']<=last_test_profit_tmsp)]
#     min_block, max_block  = blocks_time['block_heights'].min(), blocks_time['block_heights'].max()

#     print('blocks_time[block_heights].min(), blocks_time[block_heights].max()')
#     print(blocks_time['block_heights'].min(), blocks_time['block_heights'].max())

#     for wallets_chunk in wallets_list:
#         txs_of_chunk = get_txs_of_wallets_list_between_blocks(wallets_chunk, min_block, max_block)

#         if txs_of_chunk.empty:
#             continue

#         logger.info("\033[0mStart get_data_for_teach_with_dask in get_data_to_test\033[0m")
#         correletaion_chunk_df = get_data_for_teach_with_dask(peaks_data, txs_of_chunk, corelation_of_wallets_df)
#         correletaion_in_tmsps_df.append(correletaion_chunk_df)

#     if correletaion_in_tmsps_df:
#         correletaion_in_tmsps_df = pd.concat(correletaion_in_tmsps_df)
#         correletaion_in_tmsps_df = correletaion_in_tmsps_df.sort_values('Timestamp')
#         correletaion_in_tmsps_df = correletaion_in_tmsps_df.loc[correletaion_in_tmsps_df['Timestamp'] > start_test_profit_tmsp_with_cmlt+model.time_params['time_to_get_cmlt_month']*sf.get_secs_in_month()]
#         print('correletaion_df.head()')
#         print(correletaion_in_tmsps_df.head())
#         return correletaion_in_tmsps_df
#     else:
#         return pd.DataFrame()
#     # есть список корреляции кошельков
#     # есть начальная и конечная точка
#     # я получаю транзакции кошельков, которые есть в corelation_of_wallets_df дф в промежутке между точками
#     # я разбиваю их на 10и минутные промежутки идентичные тем промежуткам которые есть в iterval_with_peaks_df
#     # и считаю корреляцию в этих промежутка....(?)
#     # на выходе мне нужно получить корреляционный дф по временным 10иминутным интервала для теста моделей
    
# meta_correlation = pd.DataFrame({
#     'Wallet_id': pd.Series(dtype='object'),
#     'Normalized_sell_amount_mean': pd.Series(dtype='float64'),
#     'Normalized_sell_amount_std': pd.Series(dtype='float64'),
#     'Normalized_buy_amount_mean': pd.Series(dtype='float64'),
#     'Normalized_buy_amount_std': pd.Series(dtype='float64'),
#     'in_sell_interval_mean': pd.Series(dtype='float64'),
#     'in_sell_interval_std': pd.Series(dtype='float64'),
#     'in_buy_interval_mean': pd.Series(dtype='float64'),
#     'in_buy_interval_std': pd.Series(dtype='float64'),
#     'Amount_count': pd.Series(dtype='int64'),
#     'Amount_<lambda_0>': pd.Series(dtype='int64'),
#     'Amount_<lambda_1>': pd.Series(dtype='int64'),
#     'NSA_ISI_mean': pd.Series(dtype='float64'),
#     'NSA_ISI_std': pd.Series(dtype='float64'),
#     'NSA_ISI_sum': pd.Series(dtype='float64'),
#     'NSA_IBI_mean': pd.Series(dtype='float64'),
#     'NSA_IBI_std': pd.Series(dtype='float64'),
#     'NSA_IBI_sum': pd.Series(dtype='float64'),
#     'NBA_IBI_mean': pd.Series(dtype='float64'),
#     'NBA_IBI_std': pd.Series(dtype='float64'),
#     'NBA_IBI_sum': pd.Series(dtype='float64'),
#     'NBA_ISI_mean': pd.Series(dtype='float64'),
#     'NBA_ISI_std': pd.Series(dtype='float64'),
#     'NBA_ISI_sum': pd.Series(dtype='float64'),
#     'cor_NSA_ISI_mean': pd.Series(dtype='float64'),
#     'cor_NSA_IBI_mean': pd.Series(dtype='float64'),
#     'cor_NBA_IBI_mean': pd.Series(dtype='float64'),
#     'cor_NBA_ISI_mean': pd.Series(dtype='float64'),
#     'Weighted_sell_correlation_mean': pd.Series(dtype='float64'),
#     'Weighted_buy_correlation_mean': pd.Series(dtype='float64'),
#     'Weighted_sell_anti_correlation_mean': pd.Series(dtype='float64'),
#     'Weighted_buy_anti_correlation_mean': pd.Series(dtype='float64'),
#     'SASI_SABI_mean': pd.Series(dtype='float64'),
#     'BABI_BASI_mean': pd.Series(dtype='float64'),
#     'WSASI_WSABI_mean': pd.Series(dtype='float64'),
#     'WBABI_WBASI_mean': pd.Series(dtype='float64'),
# })