import sqlite3
import traceback
import time
import sys
from datetime import datetime

def get_count_in_table(db_path, table_name='temp_wallets'):
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        # #comment: Выполнение запроса для получения количества записей
        cursor.execute(f"SELECT COUNT(*) FROM {table_name};")
        count = cursor.fetchone()[0]
        cursor.close()
        conn.close()
        return count
    except Exception as e:
        print(f"Ошибка при подсчёте записей в таблице {table_name}: {e}")
        return None

def create_target_table(db_path, target_table='few_tx_wallets', source_table='data_table'):
    """
    1. Создает новую таблицу (например, few_tx_wallets) с такой же схемой, как у исходной таблицы (data_table).
    """
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        # #comment: создание целевой таблицы по схеме исходной таблицы (без данных)
        cursor.execute(f"CREATE TABLE IF NOT EXISTS {target_table} AS SELECT * FROM {source_table} WHERE 0;")
        conn.commit()
        print(f"Таблица {target_table} создана или уже существует.")
    except Exception as e:
        print(f"Ошибка при создании таблицы {target_table}: {e}")
        traceback.print_exc()
    finally:
        cursor.close()
        conn.close()


def create_temp_wallets_table(db_path, source_table='data_table', temp_table='temp_wallets'):
    """
    2. Создает служебную таблицу (temp_wallets) для хранения id кошельков, у которых количество транзакций ≤ 2.
       Если таблица уже существует, создание и заполнение пропускается.
    """
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        # #comment: проверка наличия служебной таблицы
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?;", (temp_table,))
        if cursor.fetchone():
            print(f"Таблица {temp_table} уже существует. Пропускаем создание и заполнение.")
            return

        # Создаем служебную таблицу temp_wallets
        cursor.execute(f"""
            CREATE TABLE {temp_table} (
                wallet_id TEXT PRIMARY KEY
            );
        """)
        conn.commit()

        # Заполняем temp_wallets идентификаторами кошельков с количеством транзакций ≤ 2
        cursor.execute(f"""
            INSERT INTO {temp_table} (wallet_id)
            SELECT Wallet_id FROM (
                SELECT Wallet_id, COUNT(*) AS cnt
                FROM {source_table}
                GROUP BY Wallet_id
            )
            WHERE cnt <= 2;
        """)
        conn.commit()
        print(f"Таблица {temp_table} успешно создана и заполнена.")
    except Exception as e:
        print(f"Ошибка при создании или заполнении таблицы {temp_table}: {e}")
        traceback.print_exc()
    finally:
        cursor.close()
        conn.close()


def optimize_db(db_path):
    """
    Включает режим WAL и устанавливает оптимальные параметры для ускорения операций записи.
    """
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        # #comment: включаем режим WAL для улучшения параллелизма и производительности записи
        cursor.execute("PRAGMA journal_mode=WAL;")
        # #comment: устанавливаем нормальную синхронизацию для ускорения записи
        cursor.execute("PRAGMA synchronous=NORMAL;")
        conn.commit()
        cursor.close()
        conn.close()
        print("База данных оптимизирована: включен режим WAL, synchronous=NORMAL.")
    except Exception as e:
        print(f"Ошибка при оптимизации БД: {e}")
        traceback.print_exc()


def process_wallets_batch(db_path, count, source_table='data_table', target_table='few_tx_wallets', 
                          temp_table='temp_wallets', wallet_ids=None):
    """
    Обрабатывает одну порцию кошельков за одну транзакцию:
    - Копирует все строки для указанных кошельков из source_table в target_table.
    - Удаляет скопированные строки из source_table.
    - Удаляет обработанные id кошельков из temp_table.
    """
    if not wallet_ids:
        return
    try:
        start_time = time.time()
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        placeholders = ','.join('?' for _ in wallet_ids)  # #comment: генерируем строку "?, ?, ... ?"
        
        # Начинаем транзакцию для всей порции
        cursor.execute("BEGIN;")
        
        # Копируем строки из source_table в target_table для всех кошельков из списка
        query_insert = f"INSERT INTO {target_table} SELECT * FROM {source_table} WHERE Wallet_id IN ({placeholders});"
        cursor.execute(query_insert, wallet_ids)
        
        # Удаляем скопированные строки из source_table
        query_delete_source = f"DELETE FROM {source_table} WHERE Wallet_id IN ({placeholders});"
        cursor.execute(query_delete_source, wallet_ids)
        
        # Удаляем id кошельков из temp_table
        query_delete_temp = f"DELETE FROM {temp_table} WHERE wallet_id IN ({placeholders});"
        cursor.execute(query_delete_temp, wallet_ids)
        
        conn.commit()  # #comment: фиксируем транзакцию для всей группы кошельков
        # print(f"Обработана порция из {len(wallet_ids)} кошельков.")
    except Exception as e:
        conn.rollback()
        print(f"Ошибка при обработке порции кошельков {wallet_ids}: {e}")
        traceback.print_exc()
    finally:
        cursor.close()
        conn.close()
        end_time = time.time()
        time_for_banch = end_time - start_time
        how_many_time_left_mins = (count//1000)*time_for_banch/60

        sys.stdout.write(f'\rМинут на выполнение: {how_many_time_left_mins} ')  # \r возвращает каретку в начало строки
        sys.stdout.flush()  # Принудительно выводим в консоль


def process_wallets(db_path, count, source_table='data_table', target_table='few_tx_wallets', 
                    temp_table='temp_wallets', batch_size=1000):
    """
    Порционно обрабатывает кошельки из temp_wallets:
    - Выбирает батчи кошельков из temp_wallets.
    - Для каждого батча вызывает process_wallets_batch.
    - Если temp_wallets пуста, таблица удаляется.
    """
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        while True:
            cursor.execute(f"SELECT wallet_id FROM {temp_table} LIMIT ?;", (batch_size,))
            wallets = [row[0] for row in cursor.fetchall()]
            if not wallets:
                print(f"Таблица {temp_table} пуста. Удаляем таблицу {temp_table}.")
                cursor.execute(f"DROP TABLE IF EXISTS {temp_table};")
                conn.commit()
                break

            process_wallets_batch(db_path, count, source_table, target_table, temp_table, wallet_ids=wallets)
            count = count-batch_size

        cursor.close()
        conn.close()
    except Exception as e:
        print(f"Ошибка при обработке кошельков: {e}")
        traceback.print_exc()

def print_now():
    print(f'Старт в {datetime.now()}')


if __name__ == "__main__":
    print_now()
    db_path = r"C:\blocks_sql_data\blocks_sql_data_db.db"
    count = get_count_in_table(db_path)
    print("Количество записей в few_tx_wallets:", count)

    # Шаг 1: Создаем целевую таблицу few_tx_wallets по схеме data_table
    create_target_table(db_path, target_table="few_tx_wallets", source_table="data_table")
    
    # Шаг 2: Создаем служебную таблицу temp_wallets и заполняем её идентификаторами кошельков с ≤ 2 транзакциями
    create_temp_wallets_table(db_path, source_table="data_table", temp_table="temp_wallets")
    
    # Шаг 2.1: Оптимизируем базу (режим WAL и synchronous=NORMAL) для ускорения записи
    optimize_db(db_path)
    
    # Шаг 3: Порционно обрабатываем кошельки из temp_wallets
    process_wallets(db_path, count, source_table="data_table", target_table="few_tx_wallets", temp_table="temp_wallets", batch_size=1000)
    
    print("Работа завершена.")
